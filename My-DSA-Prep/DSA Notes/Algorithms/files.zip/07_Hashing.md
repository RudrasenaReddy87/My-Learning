# Hashing

## 1. What is Hashing?

Hashing is a technique to map data (keys) to fixed-size values (hash codes) using a **hash function**, which are then used as indices into a **hash table** for near-instant (**average O(1)**) insertion, deletion, and lookup.

```
hash(key) → index in table
```

A good hash function should:
- Distribute keys uniformly (minimize collisions)
- Be fast to compute
- Be deterministic (same key → same hash always)

When two different keys map to the same index (a **collision**), we handle it using **collision resolution strategies**.

---

## 2. Types / Variants of Hashing

| Type | Description | Use Case |
|---|---|---|
| **Direct Addressing** | Key itself is used as an index (only works for small, known integer ranges) | Counting sort, small bounded frequency arrays |
| **Hashing with Chaining** | Each bucket holds a linked list (or dynamic array) of all keys that hash to it | Standard hashmap implementation (Java's HashMap uses this + trees) |
| **Open Addressing (Linear Probing)** | On collision, probe the next slot linearly until an empty one is found | Space-efficient hash tables |
| **Open Addressing (Quadratic Probing)** | Probe using quadratic steps (i², i²+1...) to reduce clustering | Better distribution than linear probing |
| **Double Hashing** | Use a second hash function to determine probe step size | Further reduces clustering |
| **Rolling Hash** | Hash of a "window" of characters computed incrementally (used in string matching) | Rabin-Karp algorithm, substring search |
| **Cryptographic Hashing** | One-way hash functions (SHA-256, MD5) — not for hashmaps, but for security | Password storage, checksums, blockchain |
| **Perfect Hashing** | A hash function with zero collisions for a known, static key set | Compilers (keyword lookup), read-only dictionaries |
| **Consistent Hashing** | Hashing designed to minimize re-distribution when the number of buckets/nodes changes | Distributed systems, load balancers, caching (used by CDNs) |
| **Bloom Filter (Probabilistic Hashing)** | Uses multiple hash functions + bit array to test set membership with possible false positives (no false negatives) | Fast existence checks in huge datasets (e.g., "has this URL been visited?") |

---

## 3. Step-by-Step Approach (Hashing with Chaining — Building a Hash Table from Scratch)

1. Choose table size `m` (ideally prime, for better distribution).
2. Define hash function: `index = hash(key) % m`.
3. Maintain an array of `m` buckets, each an empty list.
4. **Insert(key, value):**
   - Compute `index = hash(key) % m`.
   - Append `(key, value)` to `buckets[index]` (check if key exists first to update).
5. **Search(key):**
   - Compute `index = hash(key) % m`.
   - Linearly scan `buckets[index]` for matching key.
6. **Delete(key):**
   - Compute `index`, remove matching key from `buckets[index]`.
7. **Resize (rehash)** when load factor (`n/m`) exceeds a threshold (commonly 0.7), doubling table size and re-inserting all elements.

---

## 4. Dry Run — Hashing with Chaining

Table size `m = 5`. Hash function: `hash(key) = key % 5`.

Insert keys: `10, 15, 20, 7, 3`

| Key | hash(key) = key % 5 | Bucket index | Action |
|---|---|---|---|
| 10 | 10%5=0 | 0 | buckets[0] = [10] |
| 15 | 15%5=0 | 0 | Collision! buckets[0] = [10, 15] (chained) |
| 20 | 20%5=0 | 0 | Collision! buckets[0] = [10, 15, 20] |
| 7 | 7%5=2 | 2 | buckets[2] = [7] |
| 3 | 3%5=3 | 3 | buckets[3] = [3] |

**Final table:**
```
Index 0: [10, 15, 20]
Index 1: []
Index 2: [7]
Index 3: [3]
Index 4: []
```

**Search(15):** hash(15)=0 → scan buckets[0] = [10, 15, 20] → found at position 2 within the chain.

---

## 5. Code Implementation

### Python (Custom Hash Table with Chaining)
```python
class HashTable:
    def __init__(self, size=10):
        self.size = size
        self.table = [[] for _ in range(size)]

    def _hash(self, key):
        return hash(key) % self.size

    def insert(self, key, value):
        idx = self._hash(key)
        for pair in self.table[idx]:
            if pair[0] == key:
                pair[1] = value  # update existing
                return
        self.table[idx].append([key, value])

    def search(self, key):
        idx = self._hash(key)
        for pair in self.table[idx]:
            if pair[0] == key:
                return pair[1]
        return None

    def delete(self, key):
        idx = self._hash(key)
        self.table[idx] = [p for p in self.table[idx] if p[0] != key]

ht = HashTable(5)
ht.insert(10, "A")
ht.insert(15, "B")
ht.insert(20, "C")
print(ht.search(15))  # B
ht.delete(15)
print(ht.search(15))  # None
```

### Java (Using built-in HashMap)
```java
import java.util.*;

public class HashingExample {
    public static void main(String[] args) {
        Map<Integer, String> map = new HashMap<>();
        map.put(10, "A");
        map.put(15, "B");
        map.put(20, "C");
        System.out.println(map.get(15)); // B
        map.remove(15);
        System.out.println(map.get(15)); // null
    }
}
```

### C++ (Using unordered_map)
```cpp
#include <bits/stdc++.h>
using namespace std;

int main() {
    unordered_map<int, string> table;
    table[10] = "A";
    table[15] = "B";
    table[20] = "C";
    cout << table[15] << endl; // B
    table.erase(15);
    cout << (table.find(15) == table.end() ? "Not Found" : table[15]) << endl; // Not Found
}
```

### JavaScript (Using Map)
```javascript
const map = new Map();
map.set(10, "A");
map.set(15, "B");
map.set(20, "C");
console.log(map.get(15)); // B
map.delete(15);
console.log(map.get(15)); // undefined
```

---

## 6. Variant: Open Addressing — Linear Probing

```python
class LinearProbingHashTable:
    def __init__(self, size=10):
        self.size = size
        self.keys = [None] * size
        self.values = [None] * size

    def _hash(self, key):
        return key % self.size

    def insert(self, key, value):
        idx = self._hash(key)
        start = idx
        while self.keys[idx] is not None and self.keys[idx] != key:
            idx = (idx + 1) % self.size
            if idx == start:
                raise Exception("Hash table is full")
        self.keys[idx] = key
        self.values[idx] = value

    def search(self, key):
        idx = self._hash(key)
        start = idx
        while self.keys[idx] is not None:
            if self.keys[idx] == key:
                return self.values[idx]
            idx = (idx + 1) % self.size
            if idx == start:
                break
        return None

ht = LinearProbingHashTable(5)
ht.insert(10, "A")  # hash=0
ht.insert(15, "B")  # hash=0 collision → probe to index 1
ht.insert(20, "C")  # hash=0 collision → probe to index 2
print(ht.search(15))  # B
```

**Dry run:** Table size 5.
- insert(10): hash=0, slot 0 empty → place at 0.
- insert(15): hash=0, slot 0 occupied by 10 → probe idx=1, empty → place at 1.
- insert(20): hash=0, slot 0 occupied → probe 1 (occupied) → probe 2, empty → place at 2.

Table: `[10, 15, 20, None, None]`

---

## 7. Variant: Rolling Hash (Rabin-Karp String Matching)

Used to find a pattern in a text in average **O(n + m)** by hashing substrings incrementally instead of recomputing from scratch.

```python
def rabin_karp(text, pattern):
    n, m = len(text), len(pattern)
    if m > n:
        return -1
    base = 256
    mod = 10**9 + 7

    pattern_hash = 0
    window_hash = 0
    h = 1  # base^(m-1) % mod

    for i in range(m - 1):
        h = (h * base) % mod

    for i in range(m):
        pattern_hash = (base * pattern_hash + ord(pattern[i])) % mod
        window_hash = (base * window_hash + ord(text[i])) % mod

    for i in range(n - m + 1):
        if pattern_hash == window_hash:
            if text[i:i+m] == pattern:  # verify to avoid false positive
                return i
        if i < n - m:
            window_hash = (base * (window_hash - ord(text[i]) * h) + ord(text[i + m])) % mod
            window_hash = (window_hash + mod) % mod  # ensure non-negative

    return -1

print(rabin_karp("abcxabcdabxabcdabcdabcy", "abcdabcy"))  # 15
```

**Concept:** Instead of recomputing the hash of every substring from scratch (O(m) each), we "roll" the hash: remove the contribution of the outgoing character, shift, and add the incoming character — all in O(1) per step.

---

## 8. Variant: Bloom Filter (Probabilistic Set Membership)

```python
import hashlib

class BloomFilter:
    def __init__(self, size=100, num_hashes=3):
        self.size = size
        self.num_hashes = num_hashes
        self.bits = [0] * size

    def _hashes(self, item):
        result = []
        for i in range(self.num_hashes):
            h = int(hashlib.md5(f"{item}_{i}".encode()).hexdigest(), 16)
            result.append(h % self.size)
        return result

    def add(self, item):
        for idx in self._hashes(item):
            self.bits[idx] = 1

    def might_contain(self, item):
        return all(self.bits[idx] for idx in self._hashes(item))

bf = BloomFilter()
bf.add("apple")
bf.add("banana")
print(bf.might_contain("apple"))   # True
print(bf.might_contain("grape"))   # False (most likely)
```
**Note:** Bloom filters can have **false positives** (says "maybe present" when it's not) but **never false negatives** (if it says "definitely not present," it's guaranteed correct).

---

## 9. Common Problems Solved Using Hashing
1. Two Sum — LeetCode 1
2. Group Anagrams — LeetCode 49
3. Longest Consecutive Sequence — LeetCode 128
4. Subarray Sum Equals K (prefix sum + hashmap) — LeetCode 560
5. Copy List with Random Pointer (hashmap of node references) — LeetCode 138
6. LRU Cache (hashmap + doubly linked list) — LeetCode 146
7. Design HashMap / HashSet from scratch — LeetCode 705, 706
8. Rabin-Karp String Matching — GfG
9. Isomorphic Strings — LeetCode 205
10. Word Pattern — LeetCode 290

---

## 10. Complexity Analysis

| Operation | Average Case | Worst Case (many collisions) |
|---|---|---|
| Insert | O(1) | O(n) |
| Search | O(1) | O(n) |
| Delete | O(1) | O(n) |
| Rehash/Resize | O(n) (amortized O(1) per insert) | O(n) |
| Rolling Hash Search (Rabin-Karp) | O(n + m) | O(n·m) (rare, hash collisions) |
| Bloom Filter add/check | O(k) (k = num hash functions) | O(k) |

---

## 11. Key Takeaways
- Hashing gives **average O(1)** operations by trading a small amount of space for a huge amount of lookup speed.
- **Load factor** (`n/m`) is critical — keep it below ~0.7 and resize (rehash) when needed to maintain O(1) average performance.
- Collision resolution strategy matters: **chaining** handles high load factors gracefully; **open addressing** is more cache-friendly but degrades faster near full capacity.
- **Rolling hash** is the backbone of efficient substring search algorithms (Rabin-Karp) and is also used in plagiarism detection and DNA sequence matching.
- **Bloom filters** and **consistent hashing** are essential tools in large-scale distributed systems — know them for system design interviews.
- Hashing pairs extremely well with **Prefix Sum** (subarray sum = k problems) and **Frequency Counting** (see their respective README files).
