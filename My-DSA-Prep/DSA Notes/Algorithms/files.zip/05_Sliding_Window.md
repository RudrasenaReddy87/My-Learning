# Sliding Window Technique

## 1. What is the Sliding Window Technique?

Sliding Window is a technique for problems involving **contiguous subarrays or substrings**, where instead of recomputing from scratch for every window (which is O(n²) or worse), we maintain a "window" defined by two pointers (`start`, `end`) and **slide** it across the data, adding/removing elements incrementally — achieving **O(n)** time.

It is essentially a specialized, optimized version of the **Two Pointers (same direction)** technique, tailored for "window" or "range" based problems.

---

## 2. Types / Variants of Sliding Window

| Type | Description | Use Case |
|---|---|---|
| **Fixed Size Window** | Window size `k` is constant; slide by removing leftmost, adding rightmost | Max sum of subarray of size k, average of subarrays |
| **Variable Size Window (Expandable)** | Window grows/shrinks based on a condition | Longest substring without repeating chars, smallest subarray with sum ≥ target |
| **Variable Size — "At Most K" Pattern** | Count/find windows satisfying "at most K" constraint, often combined with subtraction trick ("exactly K" = "at most K" − "at most K-1") | Subarrays with at most K distinct elements |
| **Two Pointers Sliding Window (Shrinkable)** | Expand with `end`, shrink with `start` while condition violated | Minimum window substring |
| **Sliding Window Maximum/Minimum (Deque-based)** | Use a monotonic deque to track max/min in O(1) amortized per step | Sliding window maximum (LeetCode 239) |
| **Sliding Window with Hashmap/Frequency Counter** | Track character/element frequency inside window | Anagram search, permutation in string |
| **Multiple Windows / Sliding Window on 2 pointers each direction** | Rare, used in advanced string matching | Substring concatenation of all words |

---

## 3. Step-by-Step Approach

### A) Fixed Size Window (e.g., Max Sum Subarray of size k)
1. Compute the sum of the first `k` elements → this is the initial window sum.
2. Set `maxSum = windowSum`.
3. Slide the window from index `k` to `n-1`:
   - `windowSum = windowSum - arr[i-k] + arr[i]` (remove leftmost, add new rightmost)
   - `maxSum = max(maxSum, windowSum)`
4. Return `maxSum`.

### B) Variable Size Window (e.g., Smallest subarray with sum ≥ target)
1. Initialize `start = 0`, `windowSum = 0`, `minLength = infinity`.
2. Loop `end` from `0` to `n-1`:
   - Add `arr[end]` to `windowSum`.
   - While `windowSum >= target`:
     - Update `minLength = min(minLength, end - start + 1)`.
     - Subtract `arr[start]` from `windowSum`, move `start += 1` (shrink window).
3. Return `minLength` (or 0 if never found).

---

## 4. Dry Run — Fixed Size Window (Max Sum Subarray of size k)

Array: `arr = [2, 1, 5, 1, 3, 2]`, `k = 3`

**Step 1: Initial window sum (first 3 elements)**
```
windowSum = 2 + 1 + 5 = 8
maxSum = 8
```

**Step 2: Slide window**

| i | Remove arr[i-k] | Add arr[i] | windowSum calc | windowSum | maxSum |
|---|---|---|---|---|---|
| 3 | arr[0]=2 | arr[3]=1 | 8 - 2 + 1 | 7 | max(8,7)=8 |
| 4 | arr[1]=1 | arr[4]=3 | 7 - 1 + 3 | 9 | max(8,9)=9 |
| 5 | arr[2]=5 | arr[5]=2 | 9 - 5 + 2 | 6 | max(9,6)=9 |

**Result: maxSum = 9** (subarray `[1, 5, 1]`? let's verify: actually window at i=4 covers indices 2,3,4 = [5,1,3] = 9 ✅)

---

## 5. Dry Run — Variable Size Window (Smallest subarray with sum ≥ target)

Array: `arr = [2, 1, 5, 2, 3, 2]`, `target = 7`

| end | arr[end] | windowSum | Condition (≥7)? | Shrink actions | minLength |
|---|---|---|---|---|---|
| 0 | 2 | 2 | No | - | ∞ |
| 1 | 1 | 3 | No | - | ∞ |
| 2 | 5 | 8 | Yes | len=3(0-2); subtract arr[0]=2→windowSum=6, start=1. Now 6<7 stop shrink | 3 |
| 3 | 2 | 8 | Yes | len=3(1-3); subtract arr[1]=1→windowSum=7,start=2. Still≥7: len=2(2-3); subtract arr[2]=5→windowSum=2,start=3. Now<7 stop | 2 |
| 4 | 3 | 5 | No | - | 2 |
| 5 | 2 | 7 | Yes | len=3(3-5); subtract arr[3]=2→windowSum=5,start=4. Now<7 stop | 2 |

**Result: minLength = 2** (subarray `[5,2]` at indices 2-3, sum=7) ✅

---

## 6. Code Implementation

### Python (Fixed Size Window)
```python
def max_sum_fixed_window(arr, k):
    window_sum = sum(arr[:k])
    max_sum = window_sum
    for i in range(k, len(arr)):
        window_sum += arr[i] - arr[i - k]
        max_sum = max(max_sum, window_sum)
    return max_sum

arr = [2, 1, 5, 1, 3, 2]
print(max_sum_fixed_window(arr, 3))  # 9
```

### Python (Variable Size Window)
```python
def smallest_subarray_with_sum(arr, target):
    start = 0
    window_sum = 0
    min_len = float('inf')
    for end in range(len(arr)):
        window_sum += arr[end]
        while window_sum >= target:
            min_len = min(min_len, end - start + 1)
            window_sum -= arr[start]
            start += 1
    return min_len if min_len != float('inf') else 0

arr = [2, 1, 5, 2, 3, 2]
print(smallest_subarray_with_sum(arr, 7))  # 2
```

### Java (Fixed Size Window)
```java
public class SlidingWindow {
    static int maxSumFixedWindow(int[] arr, int k) {
        int windowSum = 0;
        for (int i = 0; i < k; i++) windowSum += arr[i];
        int maxSum = windowSum;
        for (int i = k; i < arr.length; i++) {
            windowSum += arr[i] - arr[i - k];
            maxSum = Math.max(maxSum, windowSum);
        }
        return maxSum;
    }

    public static void main(String[] args) {
        int[] arr = {2, 1, 5, 1, 3, 2};
        System.out.println(maxSumFixedWindow(arr, 3)); // 9
    }
}
```

### C++ (Variable Size Window)
```cpp
#include <bits/stdc++.h>
using namespace std;

int smallestSubarrayWithSum(vector<int>& arr, int target) {
    int start = 0, windowSum = 0, minLen = INT_MAX;
    for (int end = 0; end < (int)arr.size(); end++) {
        windowSum += arr[end];
        while (windowSum >= target) {
            minLen = min(minLen, end - start + 1);
            windowSum -= arr[start];
            start++;
        }
    }
    return minLen == INT_MAX ? 0 : minLen;
}

int main() {
    vector<int> arr = {2, 1, 5, 2, 3, 2};
    cout << smallestSubarrayWithSum(arr, 7) << endl; // 2
}
```

### JavaScript (Fixed Size Window)
```javascript
function maxSumFixedWindow(arr, k) {
    let windowSum = arr.slice(0, k).reduce((a, b) => a + b, 0);
    let maxSum = windowSum;
    for (let i = k; i < arr.length; i++) {
        windowSum += arr[i] - arr[i - k];
        maxSum = Math.max(maxSum, windowSum);
    }
    return maxSum;
}

const arr = [2, 1, 5, 1, 3, 2];
console.log(maxSumFixedWindow(arr, 3)); // 9
```

---

## 7. Variant: Longest Substring Without Repeating Characters (Hashmap-based)

```python
def longest_unique_substring(s):
    char_index = {}
    start = 0
    max_len = 0
    for end, ch in enumerate(s):
        if ch in char_index and char_index[ch] >= start:
            start = char_index[ch] + 1
        char_index[ch] = end
        max_len = max(max_len, end - start + 1)
    return max_len

print(longest_unique_substring("abcabcbb"))  # 3 ("abc")
print(longest_unique_substring("pwwkew"))    # 3 ("wke")
```

**Dry Run for `"abcabcbb"`:**
| end | char | In map & ≥start? | start updated? | max_len |
|---|---|---|---|---|
| 0 | a | No | start=0 | 1 |
| 1 | b | No | start=0 | 2 |
| 2 | c | No | start=0 | 3 |
| 3 | a | Yes (idx 0≥0) | start=1 | 3 |
| 4 | b | Yes (idx 1≥1) | start=2 | 3 |
| 5 | c | Yes (idx 2≥2) | start=3 | 3 |
| 6 | b | Yes (idx 4≥3) | start=5 | 2 |
| 7 | b | Yes (idx 6≥5) | start=7 | 1 |

**Result: 3** ✅

---

## 8. Variant: Sliding Window Maximum (Monotonic Deque)

**Problem:** Find max of every window of size `k`.

```python
from collections import deque

def sliding_window_max(arr, k):
    dq = deque()  # stores indices, values decreasing
    result = []
    for i, val in enumerate(arr):
        # Remove indices out of window
        while dq and dq[0] <= i - k:
            dq.popleft()
        # Remove smaller values from back (they're useless)
        while dq and arr[dq[-1]] < val:
            dq.pop()
        dq.append(i)
        if i >= k - 1:
            result.append(arr[dq[0]])
    return result

arr = [1, 3, -1, -3, 5, 3, 6, 7]
print(sliding_window_max(arr, 3))  # [3, 3, 5, 5, 6, 7]
```

**Concept:** The deque maintains indices in **decreasing order of value**. The front of the deque is always the max of the current window. Elements smaller than the incoming one are popped since they can never be the max while a larger, more recent element exists in the window.

---

## 9. Variant: Permutation in String (Frequency Counter Window)

```python
from collections import Counter

def check_inclusion(s1, s2):
    need = Counter(s1)
    window = Counter()
    k = len(s1)
    for i, ch in enumerate(s2):
        window[ch] += 1
        if i >= k:
            left_char = s2[i - k]
            window[left_char] -= 1
            if window[left_char] == 0:
                del window[left_char]
        if window == need:
            return True
    return False

print(check_inclusion("ab", "eidbaooo"))  # True ("ba" is a permutation of "ab")
```

---

## 10. Common Problems Solved Using Sliding Window
1. Maximum Sum Subarray of Size K
2. Longest Substring Without Repeating Characters — LeetCode 3
3. Minimum Window Substring — LeetCode 76
4. Sliding Window Maximum — LeetCode 239
5. Permutation in String — LeetCode 567
6. Longest Repeating Character Replacement — LeetCode 424
7. Subarrays with K Different Integers — LeetCode 992
8. Fruit Into Baskets — LeetCode 904
9. Max Consecutive Ones III — LeetCode 1004

---

## 11. Complexity Analysis

| Variant | Time | Space |
|---|---|---|
| Fixed size window | O(n) | O(1) |
| Variable size window | O(n) — each pointer moves forward at most n times | O(1) or O(k) if using hashmap |
| Sliding window maximum (deque) | O(n) amortized | O(k) |
| Hashmap-based window (permutation/anagram) | O(n) | O(26) or O(charset size) |

---

## 12. Key Takeaways
- Sliding Window converts brute-force O(n²) or O(n·k) subarray/substring problems into **O(n)**.
- Two main flavors: **fixed-size** (simple add/remove) and **variable-size** (expand until invalid, then shrink).
- Combine with **hashmap/frequency counters** for character/element constraint problems.
- Combine with a **monotonic deque** when you need running max/min inside the window efficiently.
- Recognize sliding window problems by keywords: "contiguous subarray," "substring," "at most K," "longest/shortest window satisfying condition."
