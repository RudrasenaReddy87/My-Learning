# Difference Array Technique

## 1. What is a Difference Array?

A Difference Array is the **inverse concept of Prefix Sum**. While prefix sum helps answer *range sum queries fast*, the difference array helps perform **range update operations fast** (add a value to every element in a range), and then recover the final array using a prefix sum pass at the end.

Given array `arr[0..n-1]`, define:

```
diff[0] = arr[0]
diff[i] = arr[i] - arr[i-1]   for i >= 1
```

**Key property:** If you do `diff[l] += val` and `diff[r+1] -= val`, then taking the prefix sum of `diff[]` reconstructs `arr[]` with `val` added to every element from index `l` to `r` — all in **O(1) per update**.

### Why it matters
Naively updating a range `[l, r]` by adding `val` to every element costs `O(r-l+1)` per update → `O(n*Q)` for Q updates.
With a difference array: `O(1)` per update, and `O(n)` to reconstruct the final array at the end → `O(n + Q)` total.

---

## 2. Types / Variants of Difference Array

| Type | Description | Use Case |
|---|---|---|
| **1D Difference Array** | Standard range-add, point-query-after-reconstruction | Range increment problems, "car pooling", flight bookings |
| **2D Difference Array** | Extension to matrices for range updates on submatrices | Adding value to a rectangular block repeatedly |
| **Difference Array with Multiple Operations** | Combine multiple ranges before single reconstruction pass | Batch processing of range updates |
| **Weighted / Scaled Difference Array** | Instead of simple add, apply linear functions (used in "range add arithmetic progression") | More advanced range update patterns |
| **Difference Array for Events (Sweep Line)** | diff array used as an event counter (+1 at start, -1 after end) | Interval overlap counting, meeting room problems |

---

## 3. Step-by-Step Approach

### Building & Using
1. Create `diff[]` array of size `n+1` (extra slot to handle boundary safely), initialized to 0.
2. For each range update `(l, r, val)`:
   - `diff[l] += val`
   - `diff[r+1] -= val`  (only if `r+1 < n`)
3. After all updates, reconstruct the final array using prefix sum:
   - `result[0] = diff[0]`
   - `result[i] = result[i-1] + diff[i]`

---

## 4. Dry Run

Start with array `arr = [0, 0, 0, 0, 0, 0]` (size 6, indices 0–5)

Apply 3 range updates:
1. Add `5` to range `[1, 3]`
2. Add `3` to range `[2, 5]`
3. Add `-2` to range `[0, 2]`

**Step 1: Initialize diff array of size 7 (n+1 = 7)**
```
diff = [0, 0, 0, 0, 0, 0, 0]
```

**Step 2: Apply update 1 → add 5 to [1,3]**
```
diff[1] += 5   → diff[1] = 5
diff[4] -= 5   → diff[4] = -5
diff = [0, 5, 0, 0, -5, 0, 0]
```

**Step 3: Apply update 2 → add 3 to [2,5]**
```
diff[2] += 3   → diff[2] = 3
diff[6] -= 3   → diff[6] = -3
diff = [0, 5, 3, 0, -5, 0, -3]
```

**Step 4: Apply update 3 → add -2 to [0,2]**
```
diff[0] += -2  → diff[0] = -2
diff[3] -= -2  → diff[3] = 2
diff = [-2, 5, 3, 2, -5, 0, -3]
```

**Step 5: Reconstruct final array via prefix sum of diff[0..5]**

| i | diff[i] | running sum (result[i]) |
|---|---|---|
| 0 | -2 | -2 |
| 1 | 5 | 3 |
| 2 | 3 | 6 |
| 3 | 2 | 8 |
| 4 | -5 | 3 |
| 5 | 0 | 3 |

**Final array = `[-2, 3, 6, 8, 3, 3]`**

### Verify manually
- Index 0: only update 3 applies → -2 ✅
- Index 1: updates 1 & 3 → 5 + (-2) = 3 ✅
- Index 2: updates 1, 2, 3 → 5+3-2 = 6 ✅
- Index 3: updates 1, 2 → 5+3 = 8 ✅
- Index 4: update 2 only → 3 ✅
- Index 5: update 2 only → 3 ✅

All match. 

---

## 5. Code Implementation

### Python
```python
def range_update(diff, l, r, val):
    diff[l] += val
    if r + 1 < len(diff):
        diff[r + 1] -= val

def build_final_array(diff, n):
    result = [0] * n
    result[0] = diff[0]
    for i in range(1, n):
        result[i] = result[i - 1] + diff[i]
    return result

n = 6
diff = [0] * (n + 1)
range_update(diff, 1, 3, 5)
range_update(diff, 2, 5, 3)
range_update(diff, 0, 2, -2)

final = build_final_array(diff, n)
print(final)   # [-2, 3, 6, 8, 3, 3]
```

### Java
```java
import java.util.Arrays;

public class DifferenceArray {
    static void rangeUpdate(int[] diff, int l, int r, int val) {
        diff[l] += val;
        if (r + 1 < diff.length) diff[r + 1] -= val;
    }

    static int[] buildFinal(int[] diff, int n) {
        int[] result = new int[n];
        result[0] = diff[0];
        for (int i = 1; i < n; i++) result[i] = result[i - 1] + diff[i];
        return result;
    }

    public static void main(String[] args) {
        int n = 6;
        int[] diff = new int[n + 1];
        rangeUpdate(diff, 1, 3, 5);
        rangeUpdate(diff, 2, 5, 3);
        rangeUpdate(diff, 0, 2, -2);
        System.out.println(Arrays.toString(buildFinal(diff, n)));
        // [-2, 3, 6, 8, 3, 3]
    }
}
```

### C++
```cpp
#include <bits/stdc++.h>
using namespace std;

void rangeUpdate(vector<int>& diff, int l, int r, int val) {
    diff[l] += val;
    if (r + 1 < (int)diff.size()) diff[r + 1] -= val;
}

vector<int> buildFinal(vector<int>& diff, int n) {
    vector<int> result(n);
    result[0] = diff[0];
    for (int i = 1; i < n; i++) result[i] = result[i-1] + diff[i];
    return result;
}

int main() {
    int n = 6;
    vector<int> diff(n + 1, 0);
    rangeUpdate(diff, 1, 3, 5);
    rangeUpdate(diff, 2, 5, 3);
    rangeUpdate(diff, 0, 2, -2);
    auto result = buildFinal(diff, n);
    for (int x : result) cout << x << " ";
    // -2 3 6 8 3 3
}
```

### JavaScript
```javascript
function rangeUpdate(diff, l, r, val) {
    diff[l] += val;
    if (r + 1 < diff.length) diff[r + 1] -= val;
}

function buildFinal(diff, n) {
    const result = new Array(n);
    result[0] = diff[0];
    for (let i = 1; i < n; i++) result[i] = result[i - 1] + diff[i];
    return result;
}

const n = 6;
const diff = new Array(n + 1).fill(0);
rangeUpdate(diff, 1, 3, 5);
rangeUpdate(diff, 2, 5, 3);
rangeUpdate(diff, 0, 2, -2);
console.log(buildFinal(diff, n)); // [-2, 3, 6, 8, 3, 3]
```

---

## 6. 2D Difference Array

For updating a rectangular submatrix `(r1,c1)` to `(r2,c2)` with value `val`:

```
diff[r1][c1]     += val
diff[r1][c2+1]   -= val
diff[r2+1][c1]   -= val
diff[r2+1][c2+1] += val
```

Then reconstruct using 2D prefix sum.

### Python Example
```python
def range_update_2d(diff, r1, c1, r2, c2, val, rows, cols):
    diff[r1][c1] += val
    if c2 + 1 < cols: diff[r1][c2 + 1] -= val
    if r2 + 1 < rows: diff[r2 + 1][c1] -= val
    if r2 + 1 < rows and c2 + 1 < cols: diff[r2 + 1][c2 + 1] += val

def build_final_2d(diff, rows, cols):
    result = [[0]*cols for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            result[i][j] = diff[i][j]
            if i > 0: result[i][j] += result[i-1][j]
            if j > 0: result[i][j] += result[i][j-1]
            if i > 0 and j > 0: result[i][j] -= result[i-1][j-1]
    return result

rows, cols = 4, 4
diff = [[0]*cols for _ in range(rows)]
range_update_2d(diff, 1, 1, 2, 2, 5, rows, cols)
final = build_final_2d(diff, rows, cols)
for row in final: print(row)
```

---

## 7. Real-World / Interview Applications
1. **Car Pooling problem** — LeetCode 1094
2. **Corporate Flight Bookings** — LeetCode 1109
3. **Range Addition** — LeetCode 370
4. **My Calendar / Meeting rooms with capacity**
5. **Efficiently applying discounts to date ranges**
6. **Interval overlap frequency counting**

---

## 8. Complexity Analysis

| Operation | Time | Space |
|---|---|---|
| Single range update | O(1) | - |
| Build diff array | O(n) | O(n) |
| Reconstruct final array | O(n) | O(n) |
| Q range updates + final build | O(n + Q) | O(n) |
| 2D range update | O(1) | - |
| 2D reconstruction | O(rows × cols) | O(rows × cols) |

---

## 9. Prefix Sum vs Difference Array — Quick Comparison

| Feature | Prefix Sum | Difference Array |
|---|---|---|
| Optimizes | Range Query (read) | Range Update (write) |
| Query type | Sum of a range | Value at a point after updates |
| Build cost | O(n) | O(1) per update |
| Use together? | Yes — diff array's *reconstruction step* IS a prefix sum | Yes — they are inverse operations of each other |

---

## 10. Key Takeaways
- Difference array shines when you have **many range updates but only need the final array once** (offline processing).
- It does NOT support fast point queries *during* the updates — you must finish all updates, then do one prefix-sum pass.
- If you need both fast range updates AND fast range queries interleaved, use a **Segment Tree with Lazy Propagation** or **Binary Indexed Tree (Fenwick Tree)** instead.
- The "sweep line" technique (marking +1 at start, -1 at end+1) used in interval problems is essentially a difference array in disguise.
