# Prefix Sum Algorithm

## 1. What is Prefix Sum?

Prefix Sum (also called Cumulative Sum) is a preprocessing technique where you build a new array `prefix[]` such that:

```
prefix[i] = arr[0] + arr[1] + ... + arr[i]
```

Once built, the sum of any subarray `arr[l..r]` can be answered in **O(1)** time instead of O(n), by using:

```
sum(l, r) = prefix[r] - prefix[l-1]      (if l > 0)
sum(l, r) = prefix[r]                    (if l == 0)
```

### Why it matters
Without prefix sums, answering `Q` range-sum queries on an array of size `n` costs `O(n*Q)`.
With prefix sums: `O(n)` to build + `O(1)` per query → `O(n + Q)` total.

---

## 2. Types / Variants of Prefix Sum

| Type | Description | Use Case |
|---|---|---|
| **1D Prefix Sum** | Cumulative sum over a linear array | Range sum queries |
| **2D Prefix Sum (Prefix Sum Matrix)** | Cumulative sum over rows & columns | Sum of a submatrix |
| **Prefix XOR** | Same idea, but with XOR instead of `+` | Range XOR queries, subarray XOR problems |
| **Prefix Product** | Cumulative product | Range product queries (careful with 0s) |
| **Prefix Max/Min** | Running max/min instead of sum | Range max/min (only works one-directionally, not subtracting) |
| **Prefix Count / Frequency Prefix** | Prefix sum on frequency array | Counting elements ≤ X in a range |
| **Difference Array (inverse of Prefix Sum)** | Used for range *update*, point query — covered in the next README | Range increment problems |
| **Weighted Prefix Sum** | prefix sum with index-based weight | Weighted range problems |

---

## 3. Step-by-Step Approach

### Building the Prefix Array
1. Create `prefix[]` of size `n` (same size as input array).
2. `prefix[0] = arr[0]`
3. For `i` from `1` to `n-1`: `prefix[i] = prefix[i-1] + arr[i]`

### Answering Range Sum Query (l, r)
1. If `l == 0`: return `prefix[r]`
2. Else: return `prefix[r] - prefix[l-1]`

---

## 4. Dry Run (1D Prefix Sum)

Array: `arr = [3, 1, 4, 1, 5, 9, 2, 6]`  (indices 0 to 7)

**Step 1: Build prefix array**

| i | arr[i] | prefix[i] calculation | prefix[i] |
|---|---|---|---|
| 0 | 3 | 3 | 3 |
| 1 | 1 | 3+1 | 4 |
| 2 | 4 | 4+4 | 8 |
| 3 | 1 | 8+1 | 9 |
| 4 | 5 | 9+5 | 14 |
| 5 | 9 | 14+9 | 23 |
| 6 | 2 | 23+2 | 25 |
| 7 | 6 | 25+6 | 31 |

`prefix = [3, 4, 8, 9, 14, 23, 25, 31]`

**Step 2: Query sum(2, 5)** → elements `arr[2..5] = [4, 1, 5, 9]` → expected sum = 19

```
sum(2,5) = prefix[5] - prefix[1] = 23 - 4 = 19 ✅
```

**Step 3: Query sum(0, 3)** → elements `[3,1,4,1]` → expected = 9

```
Since l == 0: sum(0,3) = prefix[3] = 9 ✅
```

---

## 5. Code Implementation

### Python
```python
def build_prefix(arr):
    n = len(arr)
    prefix = [0] * n
    prefix[0] = arr[0]
    for i in range(1, n):
        prefix[i] = prefix[i - 1] + arr[i]
    return prefix

def range_sum(prefix, l, r):
    if l == 0:
        return prefix[r]
    return prefix[r] - prefix[l - 1]

# Example usage
arr = [3, 1, 4, 1, 5, 9, 2, 6]
prefix = build_prefix(arr)
print(prefix)                 # [3, 4, 8, 9, 14, 23, 25, 31]
print(range_sum(prefix, 2, 5))  # 19
print(range_sum(prefix, 0, 3))  # 9
```

### Java
```java
public class PrefixSum {
    static int[] buildPrefix(int[] arr) {
        int n = arr.length;
        int[] prefix = new int[n];
        prefix[0] = arr[0];
        for (int i = 1; i < n; i++) {
            prefix[i] = prefix[i - 1] + arr[i];
        }
        return prefix;
    }

    static int rangeSum(int[] prefix, int l, int r) {
        if (l == 0) return prefix[r];
        return prefix[r] - prefix[l - 1];
    }

    public static void main(String[] args) {
        int[] arr = {3, 1, 4, 1, 5, 9, 2, 6};
        int[] prefix = buildPrefix(arr);
        System.out.println(rangeSum(prefix, 2, 5)); // 19
        System.out.println(rangeSum(prefix, 0, 3)); // 9
    }
}
```

### C++
```cpp
#include <bits/stdc++.h>
using namespace std;

vector<long long> buildPrefix(vector<int>& arr) {
    int n = arr.size();
    vector<long long> prefix(n);
    prefix[0] = arr[0];
    for (int i = 1; i < n; i++)
        prefix[i] = prefix[i - 1] + arr[i];
    return prefix;
}

long long rangeSum(vector<long long>& prefix, int l, int r) {
    if (l == 0) return prefix[r];
    return prefix[r] - prefix[l - 1];
}

int main() {
    vector<int> arr = {3, 1, 4, 1, 5, 9, 2, 6};
    auto prefix = buildPrefix(arr);
    cout << rangeSum(prefix, 2, 5) << endl; // 19
    cout << rangeSum(prefix, 0, 3) << endl; // 9
}
```

### JavaScript
```javascript
function buildPrefix(arr) {
    const n = arr.length;
    const prefix = new Array(n);
    prefix[0] = arr[0];
    for (let i = 1; i < n; i++) {
        prefix[i] = prefix[i - 1] + arr[i];
    }
    return prefix;
}

function rangeSum(prefix, l, r) {
    if (l === 0) return prefix[r];
    return prefix[r] - prefix[l - 1];
}

const arr = [3, 1, 4, 1, 5, 9, 2, 6];
const prefix = buildPrefix(arr);
console.log(rangeSum(prefix, 2, 5)); // 19
console.log(rangeSum(prefix, 0, 3)); // 9
```

---

## 6. 2D Prefix Sum (Matrix)

Used to compute the sum of any submatrix in O(1).

```
prefix[i][j] = arr[i][j] + prefix[i-1][j] + prefix[i][j-1] - prefix[i-1][j-1]
```

Query sum of submatrix from `(r1,c1)` to `(r2,c2)`:
```
sum = prefix[r2][c2] - prefix[r1-1][c2] - prefix[r2][c1-1] + prefix[r1-1][c1-1]
```

### Python Example
```python
def build_2d_prefix(matrix):
    rows, cols = len(matrix), len(matrix[0])
    prefix = [[0] * (cols + 1) for _ in range(rows + 1)]
    for i in range(1, rows + 1):
        for j in range(1, cols + 1):
            prefix[i][j] = (matrix[i-1][j-1]
                             + prefix[i-1][j]
                             + prefix[i][j-1]
                             - prefix[i-1][j-1])
    return prefix

def submatrix_sum(prefix, r1, c1, r2, c2):
    # 0-indexed inclusive coordinates
    return (prefix[r2+1][c2+1]
            - prefix[r1][c2+1]
            - prefix[r2+1][c1]
            + prefix[r1][c1])

matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]
p = build_2d_prefix(matrix)
print(submatrix_sum(p, 0, 0, 1, 1))  # 1+2+4+5 = 12
```

### Dry Run (2D)
Matrix:
```
1 2 3
4 5 6
7 8 9
```
Padded prefix (size 4x4, 1-indexed):
```
0  0  0  0
0  1  3  6
0  5 12 21
0 12 27 45
```
Query submatrix sum for rows 0-1, cols 0-1 (top-left 2x2 = [[1,2],[4,5]]):
```
sum = prefix[2][2] - prefix[0][2] - prefix[2][0] + prefix[0][0]
    = 12 - 0 - 0 + 0 = 12  ✅ (1+2+4+5=12)
```

---

## 7. Prefix XOR (Variant Example)

```python
def build_prefix_xor(arr):
    n = len(arr)
    prefix = [0]*n
    prefix[0] = arr[0]
    for i in range(1, n):
        prefix[i] = prefix[i-1] ^ arr[i]
    return prefix

def range_xor(prefix, l, r):
    if l == 0:
        return prefix[r]
    return prefix[r] ^ prefix[l-1]

arr = [8, 1, 2, 12, 5]
p = build_prefix_xor(arr)
print(range_xor(p, 1, 3))  # 1^2^12 = 15
```

---

## 8. Common Problems Solved Using Prefix Sum
1. Range Sum Query (Immutable) — LeetCode 303
2. Range Sum Query 2D — LeetCode 304
3. Subarray Sum Equals K — LeetCode 560
4. Continuous Subarray Sum — LeetCode 523
5. Product of Array Except Self (prefix + suffix product)
6. Find Pivot Index — LeetCode 724
7. Maximum Size Subarray Sum Equals k
8. Count of subarrays with equal 0s and 1s
9. Number of ways to split array with equal sum

---

## 9. Complexity Analysis

| Operation | Time | Space |
|---|---|---|
| Build prefix array | O(n) | O(n) |
| Range sum query | O(1) | - |
| Build 2D prefix | O(rows × cols) | O(rows × cols) |
| 2D range query | O(1) | - |

---

## 10. Key Takeaways
- Prefix sum trades a small amount of preprocessing time/space for extremely fast repeated range queries.
- It works for any **associative and invertible** operation: sum, XOR, product (careful with 0), but **not** directly for max/min (since max/min has no inverse operation).
- Always watch for **integer overflow** in other languages (use `long`/`long long` for large sums).
- The "prefix sum trick" (`sum == k` via hashmap of prefix sums) is one of the most powerful patterns in subarray-sum problems — see the **Hashing** and **Difference Array** README files for related techniques.
