# Frequency Counting

## 1. What is Frequency Counting?

Frequency Counting is the technique of recording **how many times each element/character appears** in a collection, using either a hashmap/dictionary or an array (when the range of values is small/known, like lowercase letters or digits). It underlies a massive number of algorithmic patterns: anagrams, majority elements, mode-finding, histogram-based problems, and more.

```
freq = {}
for element in collection:
    freq[element] = freq.get(element, 0) + 1
```

Once built, `freq` lets you answer "how many times does X appear?" in **O(1)**.

---

## 2. Types / Variants of Frequency Counting

| Type | Description | Use Case |
|---|---|---|
| **Hashmap-based Frequency Counting** | General-purpose, works for any hashable type (numbers, strings, objects) | Counting arbitrary elements |
| **Array-based Frequency Counting (Counting Sort style)** | Use an array indexed by value when range is small & known | Counting characters (26 letters), digits (0-9), bounded integers |
| **Sliding Window Frequency Counting** | Frequency map maintained over a moving window | Anagram search, permutation in string (see Sliding Window README) |
| **Frequency of Frequency** | Count how many elements have a given frequency (a "meta" frequency map) | "Elements with unique frequency count," problems like LeetCode 1636 |
| **Bit Manipulation Frequency (XOR-based)** | Special case: counting occurrences using XOR properties (works for "find the element appearing once/odd times") | Single Number problems |
| **Two-Pass Frequency Comparison** | Build frequency of two collections and compare | Anagram check, "Ransom Note," finding differences between arrays |
| **Majority Element Counting (Boyer-Moore Voting)** | Constant space technique to find majority element (>n/2) without a full frequency map | Majority Element — LeetCode 169 |
| **Top-K Frequency (Heap + Frequency Map)** | Combine frequency map with a heap to get most/least frequent K elements | Top K Frequent Elements — LeetCode 347 |

---

## 3. Step-by-Step Approach (General Hashmap-based)

1. Initialize an empty hashmap `freq`.
2. Traverse the collection once:
   - For each element `x`: `freq[x] = freq.get(x, 0) + 1`
3. Use `freq` to answer queries: existence, count, max frequency, etc.

### Step-by-Step (Array-based, e.g., lowercase letters)
1. Create `freq = [0] * 26`.
2. For each character `c` in string: `freq[ord(c) - ord('a')] += 1`.
3. Use directly indexed lookups.

---

## 4. Dry Run — Hashmap Frequency Counting

Input: `arr = [4, 2, 4, 5, 2, 4, 1]`

| Step | Element | freq map after processing |
|---|---|---|
| 1 | 4 | {4:1} |
| 2 | 2 | {4:1, 2:1} |
| 3 | 4 | {4:2, 2:1} |
| 4 | 5 | {4:2, 2:1, 5:1} |
| 5 | 2 | {4:2, 2:2, 5:1} |
| 6 | 4 | {4:3, 2:2, 5:1} |
| 7 | 1 | {4:3, 2:2, 5:1, 1:1} |

**Final freq map: `{4:3, 2:2, 5:1, 1:1}`**
→ Most frequent element = `4` (appears 3 times)

---

## 5. Dry Run — Anagram Check (Two-Pass Frequency Comparison)

Check if `"listen"` and `"silent"` are anagrams.

**Step 1: Build freq for "listen"**
```
l:1, i:1, s:1, t:1, e:1, n:1
```

**Step 2: Subtract freq using "silent"**
```
s: 1-1=0
i: 1-1=0
l: 1-1=0
e: 1-1=0
n: 1-1=0
t: 1-1=0
```

**Step 3: All counts are 0 → they are anagrams** ✅

---

## 6. Code Implementation

### Python (General Frequency Map)
```python
def frequency_count(arr):
    freq = {}
    for x in arr:
        freq[x] = freq.get(x, 0) + 1
    return freq

# Using collections.Counter (Pythonic way)
from collections import Counter
def frequency_count_pythonic(arr):
    return Counter(arr)

arr = [4, 2, 4, 5, 2, 4, 1]
print(frequency_count(arr))            # {4: 3, 2: 2, 5: 1, 1: 1}
print(frequency_count_pythonic(arr))   # Counter({4: 3, 2: 2, 5: 1, 1: 1})
```

### Python (Anagram Check)
```python
from collections import Counter

def is_anagram(s1, s2):
    return Counter(s1) == Counter(s2)

print(is_anagram("listen", "silent"))  # True
print(is_anagram("hello", "world"))    # False
```

### Java
```java
import java.util.*;

public class FrequencyCounting {
    static Map<Integer, Integer> frequencyCount(int[] arr) {
        Map<Integer, Integer> freq = new HashMap<>();
        for (int x : arr) {
            freq.put(x, freq.getOrDefault(x, 0) + 1);
        }
        return freq;
    }

    static boolean isAnagram(String s1, String s2) {
        if (s1.length() != s2.length()) return false;
        int[] freq = new int[26];
        for (char c : s1.toCharArray()) freq[c - 'a']++;
        for (char c : s2.toCharArray()) freq[c - 'a']--;
        for (int f : freq) if (f != 0) return false;
        return true;
    }

    public static void main(String[] args) {
        int[] arr = {4, 2, 4, 5, 2, 4, 1};
        System.out.println(frequencyCount(arr)); // {1=1, 2=2, 4=3, 5=1}
        System.out.println(isAnagram("listen", "silent")); // true
    }
}
```

### C++
```cpp
#include <bits/stdc++.h>
using namespace std;

unordered_map<int,int> frequencyCount(vector<int>& arr) {
    unordered_map<int,int> freq;
    for (int x : arr) freq[x]++;
    return freq;
}

bool isAnagram(string s1, string s2) {
    if (s1.size() != s2.size()) return false;
    int freq[26] = {0};
    for (char c : s1) freq[c - 'a']++;
    for (char c : s2) freq[c - 'a']--;
    for (int f : freq) if (f != 0) return false;
    return true;
}

int main() {
    vector<int> arr = {4, 2, 4, 5, 2, 4, 1};
    auto freq = frequencyCount(arr);
    for (auto& [k, v] : freq) cout << k << ":" << v << " ";
    cout << endl;
    cout << isAnagram("listen", "silent") << endl; // 1 (true)
}
```

### JavaScript
```javascript
function frequencyCount(arr) {
    const freq = {};
    for (const x of arr) {
        freq[x] = (freq[x] || 0) + 1;
    }
    return freq;
}

function isAnagram(s1, s2) {
    if (s1.length !== s2.length) return false;
    const freq = new Array(26).fill(0);
    for (const c of s1) freq[c.charCodeAt(0) - 97]++;
    for (const c of s2) freq[c.charCodeAt(0) - 97]--;
    return freq.every(f => f === 0);
}

console.log(frequencyCount([4, 2, 4, 5, 2, 4, 1])); // {1:1, 2:2, 4:3, 5:1}
console.log(isAnagram("listen", "silent")); // true
```

---

## 7. Variant: Majority Element (Boyer-Moore Voting Algorithm)

Finds the element that appears **more than n/2 times** without using extra space for a frequency map.

```python
def majority_element(arr):
    count = 0
    candidate = None
    for x in arr:
        if count == 0:
            candidate = x
        count += 1 if x == candidate else -1
    return candidate

arr = [2, 2, 1, 1, 1, 2, 2]
print(majority_element(arr))  # 2
```

**Dry Run:** `arr = [2, 2, 1, 1, 1, 2, 2]`
| x | count before | candidate | Action | count after |
|---|---|---|---|---|
| 2 | 0 | - | count==0→candidate=2 | 1 |
| 2 | 1 | 2 | x==candidate→count++ | 2 |
| 1 | 2 | 2 | x!=candidate→count-- | 1 |
| 1 | 1 | 2 | x!=candidate→count-- | 0 |
| 1 | 0 | 2 | count==0→candidate=1 | 1 |
| 2 | 1 | 1 | x!=candidate→count-- | 0 |
| 2 | 0 | 1 | count==0→candidate=2 | 1 |

**Final candidate = 2** ✅ (appears 4 times out of 7, > n/2)

---

## 8. Variant: Top K Frequent Elements (Frequency Map + Heap)

```python
from collections import Counter
import heapq

def top_k_frequent(arr, k):
    freq = Counter(arr)
    return [item for item, _ in heapq.nlargest(k, freq.items(), key=lambda x: x[1])]

arr = [1, 1, 1, 2, 2, 3]
print(top_k_frequent(arr, 2))  # [1, 2]
```

---

## 9. Variant: Single Number (XOR Frequency Trick)

Find the element that appears **once** while every other appears **twice**.

```python
def single_number(arr):
    result = 0
    for x in arr:
        result ^= x
    return result

print(single_number([4, 1, 2, 1, 2]))  # 4
```
**Why it works:** `a ^ a = 0` and `a ^ 0 = a`. All paired elements cancel out via XOR, leaving only the unique one.

---

## 10. Common Problems Solved Using Frequency Counting
1. Valid Anagram — LeetCode 242
2. Group Anagrams — LeetCode 49
3. Top K Frequent Elements — LeetCode 347
4. Majority Element / Majority Element II — LeetCode 169, 229
5. First Unique Character in a String — LeetCode 387
6. Find All Duplicates in an Array — LeetCode 442
7. Ransom Note — LeetCode 383
8. Single Number I/II/III — LeetCode 136, 137, 260
9. Sort Characters by Frequency — LeetCode 451
10. Contains Duplicate — LeetCode 217

---

## 11. Complexity Analysis

| Variant | Time | Space |
|---|---|---|
| Hashmap frequency count | O(n) | O(n) (or O(k) unique elements) |
| Array frequency count (bounded range) | O(n) | O(range size) |
| Anagram check | O(n) | O(1) (fixed alphabet) or O(n) |
| Boyer-Moore majority | O(n) | O(1) |
| Top K frequent (heap) | O(n log k) | O(n) |
| Single Number (XOR) | O(n) | O(1) |

---

## 12. Key Takeaways
- Use an **array** for frequency counting when the value range is small and known (much faster than a hashmap due to no hashing overhead).
- Use a **hashmap** when values are arbitrary, large-ranged, or non-integer (strings, objects).
- Frequency counting is often a **subroutine** inside other algorithms: sliding window (character constraints), sorting-based grouping, hashing-based lookups.
- Boyer-Moore Voting and XOR tricks show that sometimes you can solve "counting" problems in **O(1) space** without ever building an explicit frequency map — look for these special structural properties (e.g., "majority," "appears exactly once").
