# Cyclic Traversal (Cyclic Sort & Cycle-Based Techniques)

## 1. What is Cyclic Traversal?

Cyclic Traversal refers to a family of techniques that exploit **cycles** formed by the relationship between an element's **value** and its **index/position** to solve problems in **O(n) time and O(1) extra space**.

The most famous form is the **Cyclic Sort algorithm**, used when you have an array containing numbers in a known range (typically `1` to `n` or `0` to `n-1`), where each number's *value* tells you exactly which *index* it should be placed at. By repeatedly swapping elements into their "correct" position, you sort (or detect anomalies in) the array without extra space.

Core idea:
```
If arr[i] should be at index (arr[i] - 1), but isn't there yet → swap it there.
Repeat until arr[i] is in its correct position, then move to next i.
```

This is called "cyclic" because each swap chain traces out a **cycle** — following the permutation cycle until it closes back on itself.

---

## 2. Types / Variants of Cyclic Traversal

| Type | Description | Use Case |
|---|---|---|
| **Cyclic Sort (Basic)** | Sort array containing values 1 to n (or 0 to n-1) in-place | Sorting a range-bound array in O(n) |
| **Find Missing Number** | Use cyclic sort to detect which number 1..n is missing | Missing Number — LeetCode 268 |
| **Find All Missing Numbers** | Detect all missing numbers in range | Find All Numbers Disappeared in an Array — LeetCode 448 |
| **Find the Duplicate Number** | Detect duplicate via cyclic sort or Floyd's cycle detection on value-links | Find the Duplicate Number — LeetCode 287 |
| **Find All Duplicates** | Detect all duplicates in range 1..n | Find All Duplicates in an Array — LeetCode 442 |
| **Find Corrupt Pair (Missing & Duplicate)** | Find the one missing and one duplicate number simultaneously | Set Mismatch — LeetCode 645 |
| **Find First Missing Positive** | Extend cyclic sort logic to find smallest missing positive integer, even with negative/out-of-range values present | First Missing Positive — LeetCode 41 |
| **Cycle Detection via Value-as-Pointer (Floyd's)** | Treat array values as "next pointers," detect a cycle the same way as linked lists | Related to Floyd's Tortoise-and-Hare, applied on arrays |
| **Circular Array Traversal** | Traverse array as if it wraps around (using modulo indexing) | Circular Array Loop — LeetCode 457, Josephus Problem |

---

## 3. Step-by-Step Approach — Cyclic Sort (values 1 to n)

1. Set `i = 0`.
2. While `i < n`:
   - Compute `correctIndex = arr[i] - 1`.
   - If `arr[i] != arr[correctIndex]` → **swap** `arr[i]` and `arr[correctIndex]` (don't increment `i`, re-check the new value at `i`).
   - Else → `i += 1` (current element already correct, or duplicate found — move on).
3. After the loop, `arr[i] == i + 1` for all correctly placed elements.

---

## 4. Dry Run — Cyclic Sort

Array: `arr = [3, 1, 5, 4, 2]` (values 1 to 5, size 5)

| i | arr[i] | correctIndex = arr[i]-1 | arr[correctIndex] | Equal? | Action | Array after |
|---|---|---|---|---|---|---|
| 0 | 3 | 2 | 5 | No | swap(arr[0], arr[2]) | [5, 1, 3, 4, 2] |
| 0 | 5 | 4 | 2 | No | swap(arr[0], arr[4]) | [2, 1, 3, 4, 5] |
| 0 | 2 | 1 | 1 | No | swap(arr[0], arr[1]) | [1, 2, 3, 4, 5] |
| 0 | 1 | 0 | 1 | Yes | i++ | [1, 2, 3, 4, 5] |
| 1 | 2 | 1 | 2 | Yes | i++ | [1, 2, 3, 4, 5] |
| 2 | 3 | 2 | 3 | Yes | i++ | [1, 2, 3, 4, 5] |
| 3 | 4 | 3 | 4 | Yes | i++ | [1, 2, 3, 4, 5] |
| 4 | 5 | 4 | 5 | Yes | i++ | [1, 2, 3, 4, 5] |

**Final sorted array: `[1, 2, 3, 4, 5]`** ✅ Achieved in O(n) with no extra space!

**Notice the cycle:** index 0 → value 3 → goes to index 2 → value 5 → goes to index 4 → value 2 → goes to index 1 → value 1 → already correct. This chain of swaps traced a **cycle**: `0 → 2 → 4 → 1 → 0`.

---

## 5. Code Implementation

### Python (Cyclic Sort)
```python
def cyclic_sort(arr):
    i = 0
    n = len(arr)
    while i < n:
        correct_idx = arr[i] - 1
        if arr[i] != arr[correct_idx]:
            arr[i], arr[correct_idx] = arr[correct_idx], arr[i]
        else:
            i += 1
    return arr

print(cyclic_sort([3, 1, 5, 4, 2]))  # [1, 2, 3, 4, 5]
```

### Java
```java
public class CyclicSort {
    static void cyclicSort(int[] arr) {
        int i = 0;
        while (i < arr.length) {
            int correctIdx = arr[i] - 1;
            if (arr[i] != arr[correctIdx]) {
                int temp = arr[i];
                arr[i] = arr[correctIdx];
                arr[correctIdx] = temp;
            } else {
                i++;
            }
        }
    }

    public static void main(String[] args) {
        int[] arr = {3, 1, 5, 4, 2};
        cyclicSort(arr);
        System.out.println(java.util.Arrays.toString(arr)); // [1, 2, 3, 4, 5]
    }
}
```

### C++
```cpp
#include <bits/stdc++.h>
using namespace std;

void cyclicSort(vector<int>& arr) {
    int i = 0, n = arr.size();
    while (i < n) {
        int correctIdx = arr[i] - 1;
        if (arr[i] != arr[correctIdx]) {
            swap(arr[i], arr[correctIdx]);
        } else {
            i++;
        }
    }
}

int main() {
    vector<int> arr = {3, 1, 5, 4, 2};
    cyclicSort(arr);
    for (int x : arr) cout << x << " "; // 1 2 3 4 5
}
```

### JavaScript
```javascript
function cyclicSort(arr) {
    let i = 0;
    while (i < arr.length) {
        const correctIdx = arr[i] - 1;
        if (arr[i] !== arr[correctIdx]) {
            [arr[i], arr[correctIdx]] = [arr[correctIdx], arr[i]];
        } else {
            i++;
        }
    }
    return arr;
}

console.log(cyclicSort([3, 1, 5, 4, 2])); // [1, 2, 3, 4, 5]
```

---

## 6. Variant: Find the Missing Number (0 to n)

```python
def find_missing_number(arr):
    i = 0
    n = len(arr)
    while i < n:
        correct_idx = arr[i]
        if arr[i] < n and arr[i] != arr[correct_idx]:
            arr[i], arr[correct_idx] = arr[correct_idx], arr[i]
        else:
            i += 1
    for i in range(n):
        if arr[i] != i:
            return i
    return n

print(find_missing_number([4, 0, 3, 1]))  # 2
```

**Dry Run:** `arr = [4, 0, 3, 1]`, n=4 (range 0 to 4, one number missing)
- i=0: arr[0]=4, correctIdx=4, but 4 is NOT < n(4) → skip condition → i=1
- i=1: arr[1]=0, correctIdx=0, arr[0]=4≠0 → swap → [0,4,3,1]
- i=1: arr[1]=4, correctIdx=4, not<n → i=2
- i=2: arr[2]=3, correctIdx=3, arr[3]=1≠3 → swap → [0,4,1,3]
- i=2: arr[2]=1, correctIdx=1, arr[1]=4≠1 → swap → [0,1,4,3]
- i=2: arr[2]=4, correctIdx=4, not<n → i=3
- i=3: arr[3]=3, correctIdx=3, arr[3]==arr[3] → i=4, loop ends

Final array: `[0,1,4,3]`. Now scan: index0=0✓, index1=1✓, index2=4≠2 → **missing = 2** ✅

---

## 7. Variant: Find the Duplicate Number (Floyd's Cycle Detection on Array)

**Problem:** Array of n+1 integers where each value is in `[1, n]`, exactly one duplicate. Find it without modifying the array, O(1) space.

**Insight:** Treat `arr[i]` as a "pointer" to the next index — this creates a linked-list-like structure with a guaranteed cycle (because of the duplicate), so Floyd's Tortoise & Hare works.

```python
def find_duplicate(nums):
    slow = fast = nums[0]
    while True:
        slow = nums[slow]
        fast = nums[nums[fast]]
        if slow == fast:
            break
    slow2 = nums[0]
    while slow2 != slow:
        slow2 = nums[slow2]
        slow = nums[slow]
    return slow

print(find_duplicate([1, 3, 4, 2, 2]))  # 2
```

**Dry Run:** `nums = [1,3,4,2,2]`
- Phase 1 (find meeting point):
  - slow=nums[0]=1, fast=nums[nums[0]]=nums[1]=3
  - slow=nums[1]=3, fast=nums[nums[3]]=nums[2]=4
  - slow=nums[3]=2, fast=nums[nums[4]]=nums[2]=4
  - slow=nums[2]=4, fast=nums[nums[4]]=nums[2]=4 → slow==fast==4, break
- Phase 2 (find entry point of cycle = duplicate):
  - slow2=nums[0]=1, slow=nums[4]=2 → not equal
  - slow2=nums[1]=3, slow=nums[2]=4 → not equal
  - slow2=nums[3]=2, slow=nums[4]=2 → equal! return 2

**Duplicate = 2** ✅

---

## 8. Variant: Set Mismatch (Find Missing AND Duplicate)

```python
def find_error_nums(nums):
    i = 0
    n = len(nums)
    while i < n:
        correct_idx = nums[i] - 1
        if nums[i] != nums[correct_idx]:
            nums[i], nums[correct_idx] = nums[correct_idx], nums[i]
        else:
            i += 1
    for i in range(n):
        if nums[i] != i + 1:
            return [nums[i], i + 1]  # [duplicate, missing]
    return [-1, -1]

print(find_error_nums([1, 2, 2, 4]))  # [2, 3]
```

---

## 9. Variant: First Missing Positive (Handles negatives/out-of-range too)

```python
def first_missing_positive(nums):
    n = len(nums)
    i = 0
    while i < n:
        correct_idx = nums[i] - 1
        if 0 < nums[i] <= n and nums[i] != nums[correct_idx]:
            nums[i], nums[correct_idx] = nums[correct_idx], nums[i]
        else:
            i += 1
    for i in range(n):
        if nums[i] != i + 1:
            return i + 1
    return n + 1

print(first_missing_positive([3, 4, -1, 1]))  # 2
print(first_missing_positive([1, 2, 0]))      # 3
```

---

## 10. Variant: Circular Array Traversal

Used for problems where you move through an array as if it "wraps around" (index `n-1` connects back to index `0`).

```python
def circular_array_loop(nums):
    n = len(nums)

    def next_index(i):
        return (i + nums[i]) % n

    for i in range(n):
        slow, fast = i, i
        # Direction must remain consistent (all forward or all backward)
        forward = nums[i] > 0
        while True:
            slow = next_index(slow)
            if (nums[slow] > 0) != forward or nums[slow] == 0:
                break
            fast = next_index(fast)
            if (nums[fast] > 0) != forward or nums[fast] == 0:
                break
            fast = next_index(fast)
            if (nums[fast] > 0) != forward or nums[fast] == 0:
                break
            if slow == fast:
                if slow == next_index(slow):  # single-element cycle isn't valid
                    break
                return True
    return False

print(circular_array_loop([2, -1, 1, 2, 2]))  # True
```

---

## 11. Common Problems Solved Using Cyclic Traversal
1. Cyclic Sort (basic) — GfG / Educative pattern
2. Missing Number — LeetCode 268
3. Find All Numbers Disappeared in an Array — LeetCode 448
4. Find the Duplicate Number — LeetCode 287
5. Find All Duplicates in an Array — LeetCode 442
6. Set Mismatch — LeetCode 645
7. First Missing Positive — LeetCode 41
8. Circular Array Loop — LeetCode 457
9. Josephus Problem (circular elimination)

---

## 12. Complexity Analysis

| Variant | Time | Space |
|---|---|---|
| Cyclic Sort | O(n) | O(1) |
| Find Missing Number | O(n) | O(1) |
| Find Duplicate (Floyd's) | O(n) | O(1) |
| Set Mismatch | O(n) | O(1) |
| First Missing Positive | O(n) | O(1) |
| Circular Array Loop | O(n) | O(1) |

**Why O(n) despite nested-looking swaps?** Each swap places at least one element into its final correct position permanently. Since there are only `n` elements, there can be at most `n` "productive" swaps total across the entire run — so the total work is bounded by O(n), not O(n²), even though it looks like a while-loop inside a while-loop.

---

## 13. Key Takeaways
- Cyclic Traversal techniques apply specifically when array values lie in a **known, bounded range related to the array's indices** (commonly `1..n` or `0..n-1`).
- The core trick: **use the array itself as a hashmap** — an element's value tells you exactly where it "belongs," so you don't need extra space to detect anomalies (missing/duplicate values).
- Floyd's Cycle Detection (Tortoise and Hare) generalizes beautifully from linked lists to arrays when array values act as "next pointers."
- These techniques achieve O(n) time and **O(1) extra space** — a big win over hashset-based (`O(n)` space) approaches for the same problems.
- Related techniques: **In-place Array Manipulation** (next README) builds on the same "no extra space" philosophy.
