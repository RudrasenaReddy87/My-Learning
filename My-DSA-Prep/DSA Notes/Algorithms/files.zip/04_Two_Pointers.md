# Two Pointers Technique

## 1. What is the Two Pointers Technique?

Two Pointers is a technique where **two index variables (pointers)** traverse a data structure (usually a sorted array, string, or linked list) — either moving towards each other, in the same direction, or at different speeds — to solve a problem in **O(n)** or **O(n log n)** time instead of the naive **O(n²)**.

It avoids nested loops by cleverly using the **order/structure** of the data (often requires sorted input) to eliminate unnecessary comparisons.

---

## 2. Types / Variants of Two Pointers

| Type | Pointer Movement | Use Case |
|---|---|---|
| **Opposite Direction (Converging)** | `left` starts at 0, `right` starts at n-1, move toward each other | Pair sum in sorted array, palindrome check, container with most water |
| **Same Direction (Fast & Slow)** | Both pointers move forward, but at different speeds/conditions | Removing duplicates, cycle detection (Floyd's), sliding window base |
| **Fast-Slow Pointers (Floyd's Cycle Detection)** | `slow` moves 1 step, `fast` moves 2 steps | Linked list cycle detection, finding middle of linked list |
| **Two Pointers on Two Different Arrays** | One pointer per array, both move forward | Merging two sorted arrays, intersection of two arrays |
| **Three Pointers** | Extension for 3-sum type problems (fix one, two-pointer on rest) | 3Sum, 3Sum Closest |
| **Sliding Window (special case)** | Both pointers move forward, forming a "window" | Covered separately in Sliding Window README |

---

## 3. Step-by-Step Approach (Opposite Direction — Classic Pair Sum)

**Problem:** Given a sorted array, find if there's a pair with sum = target.

1. Initialize `left = 0`, `right = n - 1`.
2. While `left < right`:
   - Compute `currentSum = arr[left] + arr[right]`.
   - If `currentSum == target` → found the pair, return.
   - If `currentSum < target` → move `left` forward (`left += 1`) to increase sum.
   - If `currentSum > target` → move `right` backward (`right -= 1`) to decrease sum.
3. If loop ends without match → no pair exists.

---

## 4. Dry Run

Sorted array: `arr = [2, 7, 11, 15, 18, 24]`, target = `26`

| Step | left | right | arr[left] | arr[right] | sum | Action |
|---|---|---|---|---|---|---|
| 1 | 0 | 5 | 2 | 24 | 26 | sum == target → **FOUND (2,24)** |

Let's try target = `20` instead:

| Step | left | right | arr[left] | arr[right] | sum | Action |
|---|---|---|---|---|---|---|
| 1 | 0 | 5 | 2 | 24 | 26 | 26 > 20 → right-- |
| 2 | 0 | 4 | 2 | 18 | 20 | sum == target → **FOUND (2,18)** |

Try target = `40` (no such pair exists):

| Step | left | right | arr[left] | arr[right] | sum | Action |
|---|---|---|---|---|---|---|
| 1 | 0 | 5 | 2 | 24 | 26 | 26 < 40 → left++ |
| 2 | 1 | 5 | 7 | 24 | 31 | 31 < 40 → left++ |
| 3 | 2 | 5 | 11 | 24 | 35 | 35 < 40 → left++ |
| 4 | 3 | 5 | 15 | 24 | 39 | 39 < 40 → left++ |
| 5 | 4 | 5 | 18 | 24 | 42 | 42 > 40 → right-- |
| 6 | 4 | 4 | left==right → **loop ends, no pair found** |

---

## 5. Code Implementation

### Python (Pair Sum — Opposite Direction)
```python
def two_sum_sorted(arr, target):
    left, right = 0, len(arr) - 1
    while left < right:
        curr_sum = arr[left] + arr[right]
        if curr_sum == target:
            return (arr[left], arr[right])
        elif curr_sum < target:
            left += 1
        else:
            right -= 1
    return None

arr = [2, 7, 11, 15, 18, 24]
print(two_sum_sorted(arr, 26))  # (2, 24)
print(two_sum_sorted(arr, 40))  # None
```

### Java
```java
public class TwoPointers {
    static int[] twoSumSorted(int[] arr, int target) {
        int left = 0, right = arr.length - 1;
        while (left < right) {
            int sum = arr[left] + arr[right];
            if (sum == target) return new int[]{arr[left], arr[right]};
            else if (sum < target) left++;
            else right--;
        }
        return null;
    }

    public static void main(String[] args) {
        int[] arr = {2, 7, 11, 15, 18, 24};
        int[] result = twoSumSorted(arr, 26);
        System.out.println(result[0] + ", " + result[1]); // 2, 24
    }
}
```

### C++
```cpp
#include <bits/stdc++.h>
using namespace std;

pair<int,int> twoSumSorted(vector<int>& arr, int target) {
    int left = 0, right = arr.size() - 1;
    while (left < right) {
        int sum = arr[left] + arr[right];
        if (sum == target) return {arr[left], arr[right]};
        else if (sum < target) left++;
        else right--;
    }
    return {-1, -1};
}

int main() {
    vector<int> arr = {2, 7, 11, 15, 18, 24};
    auto result = twoSumSorted(arr, 26);
    cout << result.first << ", " << result.second << endl; // 2, 24
}
```

### JavaScript
```javascript
function twoSumSorted(arr, target) {
    let left = 0, right = arr.length - 1;
    while (left < right) {
        const sum = arr[left] + arr[right];
        if (sum === target) return [arr[left], arr[right]];
        else if (sum < target) left++;
        else right--;
    }
    return null;
}

const arr = [2, 7, 11, 15, 18, 24];
console.log(twoSumSorted(arr, 26)); // [2, 24]
```

---

## 6. Variant: Same Direction (Fast & Slow) — Remove Duplicates from Sorted Array

**Problem:** Remove duplicates in-place from sorted array, return new length.

```python
def remove_duplicates(arr):
    if not arr:
        return 0
    slow = 0
    for fast in range(1, len(arr)):
        if arr[fast] != arr[slow]:
            slow += 1
            arr[slow] = arr[fast]
    return slow + 1

arr = [1, 1, 2, 2, 2, 3, 4, 4, 5]
length = remove_duplicates(arr)
print(arr[:length])  # [1, 2, 3, 4, 5]
```

**Dry Run:**
| fast | arr[fast] | arr[slow] | Condition | Action | slow |
|---|---|---|---|---|---|
| 1 | 1 | 1 | equal | skip | 0 |
| 2 | 2 | 1 | different | slow=1, arr[1]=2 | 1 |
| 3 | 2 | 2 | equal | skip | 1 |
| 4 | 2 | 2 | equal | skip | 1 |
| 5 | 3 | 2 | different | slow=2, arr[2]=3 | 2 |
| 6 | 4 | 3 | different | slow=3, arr[3]=4 | 3 |
| 7 | 4 | 4 | equal | skip | 3 |
| 8 | 5 | 4 | different | slow=4, arr[4]=5 | 4 |

Final array (first 5 elements): `[1, 2, 3, 4, 5]` ✅

---

## 7. Variant: Fast-Slow Pointers — Floyd's Cycle Detection (Linked List)

```python
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

def has_cycle(head):
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow == fast:
            return True
    return False
```

**Concept:** `slow` moves 1 node at a time, `fast` moves 2 nodes at a time. If there's a cycle, `fast` will eventually "lap" `slow` and they'll meet. If no cycle, `fast` reaches `None` first.

---

## 8. Variant: Two Pointers on Two Different Arrays — Merge Sorted Arrays

```python
def merge_sorted(arr1, arr2):
    i, j = 0, 0
    result = []
    while i < len(arr1) and j < len(arr2):
        if arr1[i] <= arr2[j]:
            result.append(arr1[i]); i += 1
        else:
            result.append(arr2[j]); j += 1
    result.extend(arr1[i:])
    result.extend(arr2[j:])
    return result

print(merge_sorted([1, 3, 5], [2, 4, 6]))  # [1, 2, 3, 4, 5, 6]
```

---

## 9. Variant: Three Pointers — 3Sum Problem

**Problem:** Find all unique triplets that sum to 0.

```python
def three_sum(nums):
    nums.sort()
    n = len(nums)
    result = []
    for i in range(n - 2):
        if i > 0 and nums[i] == nums[i - 1]:
            continue  # skip duplicates
        left, right = i + 1, n - 1
        while left < right:
            total = nums[i] + nums[left] + nums[right]
            if total == 0:
                result.append([nums[i], nums[left], nums[right]])
                left += 1; right -= 1
                while left < right and nums[left] == nums[left-1]: left += 1
                while left < right and nums[right] == nums[right+1]: right -= 1
            elif total < 0:
                left += 1
            else:
                right -= 1
    return result

print(three_sum([-1, 0, 1, 2, -1, -4]))
# [[-1, -1, 2], [-1, 0, 1]]
```

**Approach summary:** Fix one number `nums[i]`, then run classic two-pointer (opposite direction) on the remaining subarray to find pairs summing to `-nums[i]`.

---

## 10. Common Problems Solved Using Two Pointers
1. Two Sum II (sorted array) — LeetCode 167
2. 3Sum / 3Sum Closest — LeetCode 15, 16
3. Container With Most Water — LeetCode 11
4. Trapping Rain Water — LeetCode 42
5. Valid Palindrome — LeetCode 125
6. Remove Duplicates from Sorted Array — LeetCode 26
7. Linked List Cycle Detection — LeetCode 141
8. Sort Colors (Dutch National Flag — 3 pointers) — LeetCode 75
9. Merge Sorted Array — LeetCode 88
10. Squares of a Sorted Array — LeetCode 977

---

## 11. Complexity Analysis

| Variant | Time | Space |
|---|---|---|
| Opposite direction pair search | O(n) | O(1) |
| Same direction (remove dup) | O(n) | O(1) |
| Floyd's cycle detection | O(n) | O(1) |
| Merge two sorted arrays | O(n + m) | O(n + m) |
| 3Sum (sort + two pointers) | O(n²) | O(1) extra (excluding sort/output) |

---

## 12. Key Takeaways
- Two Pointers usually **requires sorted data** (or a structure with a monotonic property) to safely decide which pointer to move.
- It transforms an O(n²) brute-force nested loop into an O(n) or O(n log n) solution.
- Recognize two-pointer opportunities when: the array is sorted, you're looking for pairs/triplets with a target property, or you need in-place modification with two markers.
- Sliding Window is technically a specialized form of the "same direction" two-pointer pattern — see the dedicated Sliding Window README.
