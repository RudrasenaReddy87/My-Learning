# Algorithm Mastery Series — Index

A complete, detailed reference series covering 10 essential array/string algorithmic patterns frequently used in competitive programming and technical interviews. Each README contains: concept explanation, all major **types/variants**, a **step-by-step approach**, **hand-traced dry runs**, **multi-language code** (Python, Java, C++, JavaScript), **common problems**, and **complexity analysis**.

## Files in this series

| # | File | Topic | Key Idea |
|---|---|---|---|
| 1 | `01_Prefix_Sum.md` | Prefix Sum | Fast range-sum queries via cumulative precomputation |
| 2 | `02_Difference_Array.md` | Difference Array | Fast range-update via inverse of prefix sum |
| 3 | `03_Kadanes_Algorithm.md` | Kadane's Algorithm | Maximum subarray sum in O(n) using local extend-or-restart decision |
| 4 | `04_Two_Pointers.md` | Two Pointers | Converging/parallel indices to avoid O(n²) nested loops |
| 5 | `05_Sliding_Window.md` | Sliding Window | Maintaining a moving range for contiguous subarray/substring problems |
| 6 | `06_Frequency_Counting.md` | Frequency Counting | Counting occurrences via hashmap/array for O(1) lookups |
| 7 | `07_Hashing.md` | Hashing | Mapping keys to indices for average O(1) insert/search/delete |
| 8 | `08_Sorting_Based_Techniques.md` | Sorting-based Techniques | Sorting algorithms + sort-first problem-solving strategies |
| 9 | `09_Cyclic_Traversal.md` | Cyclic Traversal | Using value-as-index relationships to sort/detect anomalies in O(1) space |
| 10 | `10_Inplace_Array_Manipulation.md` | In-place Array Manipulation | Modifying arrays without extra space via swapping/marking/encoding |

## Suggested Learning Order

```
Sorting-Based Techniques  ─┐
                            ├──► Two Pointers ──► Sliding Window
Frequency Counting ────────┘
        │
        ▼
     Hashing ──► Prefix Sum ──► Difference Array ──► Kadane's Algorithm
        │
        ▼
Cyclic Traversal ──► In-place Array Manipulation
```

**Reasoning for this order:**
1. Start with **Sorting** and **Frequency Counting** — foundational building blocks used everywhere else.
2. Learn **Two Pointers**, then **Sliding Window** (a specialized form of two pointers).
3. Learn **Hashing** — pairs naturally with frequency counting and unlocks O(1) lookup patterns used across the rest.
4. Learn **Prefix Sum**, then **Difference Array** (its inverse), then **Kadane's Algorithm** (a special DP application closely related to prefix-sum thinking).
5. Finish with **Cyclic Traversal** and **In-place Array Manipulation** — both focus on the "zero extra space" mindset and are often combined in advanced interview problems.

## How Each File is Structured
1. **What is it?** — core definition and intuition
2. **Types / Variants** — a full breakdown table of every major sub-pattern
3. **Step-by-Step Approach** — the algorithmic recipe
4. **Dry Run** — a hand-traced example, step by step, with tables
5. **Code Implementation** — Python, Java, C++, and JavaScript
6. **Variant deep-dives** — extended examples for each major variant listed in the types table
7. **Common Problems** — curated list of well-known practice problems (mostly LeetCode)
8. **Complexity Analysis** — time/space table for every variant
9. **Key Takeaways** — practical tips, gotchas, and connections to other patterns

## Cross-Pattern Connections
- **Prefix Sum + Hashing** → "Subarray Sum Equals K" style problems (store prefix sums in a hashmap).
- **Sliding Window + Frequency Counting** → Anagram/permutation-in-string problems.
- **Sorting + Two Pointers** → 3Sum, 4Sum, Closest Pair problems.
- **Cyclic Traversal + In-place Manipulation** → Missing/Duplicate number family of problems, all solvable in O(1) space.
- **Kadane's Algorithm** is itself a compressed, O(1)-space form of Dynamic Programming — a great bridge into the broader DP topic.

---
*Happy learning! Each file is self-contained — start with any topic depending on what you want to master first, or follow the suggested learning order above.*
