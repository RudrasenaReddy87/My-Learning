# In-place Array Manipulation

## 1. What is In-place Array Manipulation?

In-place Array Manipulation refers to algorithms that modify an array **directly within its original memory**, using **O(1) extra space** (or at most O(log n) for recursion stack in some cases), instead of creating a new array or data structure. This is a critical skill for interviews and for memory-constrained systems.

The general philosophy: **use the array's own cells as your "workspace"** — via swapping, marking (using sign flips, offsetting values, or encoding two values into one cell), or overwriting positions that are no longer needed.

---

## 2. Types / Categories of In-place Techniques

| Type | Description | Use Case |
|---|---|---|
| **In-place Swapping** | Rearranging elements via swaps (no new array) | Reverse array, rotate array, Dutch National Flag |
| **In-place Overwrite (Two-Pointer Write)** | Use a "write pointer" to overwrite array from the front as you scan | Remove element, move zeroes, remove duplicates |
| **In-place Marking via Sign Flip** | Use negative sign on `arr[index]` to mark "index has been visited/seen" (works when all values are positive) | Find duplicates, find missing numbers |
| **In-place Marking via Value Encoding** | Encode two pieces of info into one cell using modulo/division tricks | Problems needing "before" and "after" value in same cell |
| **In-place Rotation (Reversal Algorithm)** | Rotate array using 3 reversals instead of extra array | Rotate Array — LeetCode 189 |
| **In-place Matrix Transformation** | Rotate/transpose a matrix without extra matrix | Rotate Image — LeetCode 48 |
| **In-place Partitioning (Dutch National Flag)** | 3-way partition using 3 pointers | Sort Colors — LeetCode 75 |
| **In-place Merging** | Merge two sorted structures within existing space (e.g., merge sorted array into one with spare capacity) | Merge Sorted Array — LeetCode 88 |
| **Cyclic Sort-based In-place** | (see dedicated Cyclic Traversal README) | Missing/duplicate number problems |

---

## 3. Step-by-Step Approach — Reverse an Array In-place

1. Initialize `left = 0`, `right = n - 1`.
2. While `left < right`:
   - Swap `arr[left]` and `arr[right]`.
   - `left += 1`, `right -= 1`.
3. Done — array is reversed with O(1) extra space.

## 4. Step-by-Step Approach — Rotate Array by K (Reversal Algorithm)

To rotate array right by `k` positions in-place:
1. Reverse the entire array.
2. Reverse the first `k` elements.
3. Reverse the remaining `n-k` elements.

---

## 5. Dry Run — Rotate Array Right by K (Reversal Algorithm)

Array: `arr = [1, 2, 3, 4, 5, 6, 7]`, `k = 3`

**Step 1: Reverse entire array**
```
[7, 6, 5, 4, 3, 2, 1]
```

**Step 2: Reverse first k=3 elements**
```
[5, 6, 7, 4, 3, 2, 1]
```

**Step 3: Reverse remaining n-k=4 elements (indices 3 to 6)**
```
[5, 6, 7, 1, 2, 3, 4]
```

**Final rotated array: `[5, 6, 7, 1, 2, 3, 4]`** ✅ (last 3 elements moved to front)

---

## 6. Code Implementation — Rotate Array

### Python
```python
def reverse(arr, start, end):
    while start < end:
        arr[start], arr[end] = arr[end], arr[start]
        start += 1
        end -= 1

def rotate_array(arr, k):
    n = len(arr)
    k = k % n
    reverse(arr, 0, n - 1)
    reverse(arr, 0, k - 1)
    reverse(arr, k, n - 1)
    return arr

print(rotate_array([1,2,3,4,5,6,7], 3))  # [5,6,7,1,2,3,4]
```

### Java
```java
public class RotateArray {
    static void reverse(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++; end--;
        }
    }

    static void rotate(int[] arr, int k) {
        int n = arr.length;
        k = k % n;
        reverse(arr, 0, n - 1);
        reverse(arr, 0, k - 1);
        reverse(arr, k, n - 1);
    }

    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5,6,7};
        rotate(arr, 3);
        System.out.println(java.util.Arrays.toString(arr)); // [5,6,7,1,2,3,4]
    }
}
```

### C++
```cpp
#include <bits/stdc++.h>
using namespace std;

void rotateArray(vector<int>& arr, int k) {
    int n = arr.size();
    k %= n;
    reverse(arr.begin(), arr.end());
    reverse(arr.begin(), arr.begin() + k);
    reverse(arr.begin() + k, arr.end());
}

int main() {
    vector<int> arr = {1,2,3,4,5,6,7};
    rotateArray(arr, 3);
    for (int x : arr) cout << x << " "; // 5 6 7 1 2 3 4
}
```

### JavaScript
```javascript
function reverse(arr, start, end) {
    while (start < end) {
        [arr[start], arr[end]] = [arr[end], arr[start]];
        start++; end--;
    }
}

function rotateArray(arr, k) {
    const n = arr.length;
    k = k % n;
    reverse(arr, 0, n - 1);
    reverse(arr, 0, k - 1);
    reverse(arr, k, n - 1);
    return arr;
}

console.log(rotateArray([1,2,3,4,5,6,7], 3)); // [5,6,7,1,2,3,4]
```

---

## 7. Variant: Move Zeroes to End (In-place Overwrite / Two-Pointer Write)

```python
def move_zeroes(arr):
    write_idx = 0
    for read_idx in range(len(arr)):
        if arr[read_idx] != 0:
            arr[write_idx], arr[read_idx] = arr[read_idx], arr[write_idx]
            write_idx += 1
    return arr

print(move_zeroes([0, 1, 0, 3, 12]))  # [1, 3, 12, 0, 0]
```

**Dry Run:** `arr = [0, 1, 0, 3, 12]`
| read_idx | arr[read_idx] | Non-zero? | Action | write_idx after | array state |
|---|---|---|---|---|---|
| 0 | 0 | No | skip | 0 | [0,1,0,3,12] |
| 1 | 1 | Yes | swap(0,1) | 1 | [1,0,0,3,12] |
| 2 | 0 | No | skip | 1 | [1,0,0,3,12] |
| 3 | 3 | Yes | swap(1,3) | 2 | [1,3,0,0,12] |
| 4 | 12 | Yes | swap(2,4) | 3 | [1,3,12,0,0] |

**Final: `[1, 3, 12, 0, 0]`** ✅

---

## 8. Variant: Dutch National Flag (3-Way In-place Partition) — Sort Colors

**Problem:** Sort array of 0s, 1s, 2s in-place in one pass.

```python
def sort_colors(arr):
    low, mid, high = 0, 0, len(arr) - 1
    while mid <= high:
        if arr[mid] == 0:
            arr[low], arr[mid] = arr[mid], arr[low]
            low += 1; mid += 1
        elif arr[mid] == 1:
            mid += 1
        else:  # arr[mid] == 2
            arr[mid], arr[high] = arr[high], arr[mid]
            high -= 1  # don't increment mid, need to recheck swapped value
    return arr

print(sort_colors([2, 0, 2, 1, 1, 0]))  # [0, 0, 1, 1, 2, 2]
```

**Dry Run:** `arr = [2, 0, 2, 1, 1, 0]`
| low | mid | high | arr[mid] | Action | Array |
|---|---|---|---|---|---|
| 0 | 0 | 5 | 2 | swap(mid,high), high-- | [0,0,2,1,1,2] |
| 0 | 0 | 4 | 0 | swap(low,mid), low++,mid++ | [0,0,2,1,1,2] |
| 1 | 1 | 4 | 0 | swap(low,mid), low++,mid++ | [0,0,2,1,1,2] |
| 2 | 2 | 4 | 2 | swap(mid,high), high-- | [0,0,1,1,2,2] |
| 2 | 2 | 3 | 1 | mid++ | [0,0,1,1,2,2] |
| 2 | 3 | 3 | 1 | mid++ | [0,0,1,1,2,2] |
| - | 4 | 3 | mid>high → stop | | [0,0,1,1,2,2] |

**Final: `[0, 0, 1, 1, 2, 2]`** ✅

---

## 9. Variant: In-place Marking via Sign Flip — Find All Duplicates

**Problem:** Array of size n with values in `[1, n]`, find all duplicates, O(1) extra space (besides output).

```python
def find_duplicates(arr):
    result = []
    for x in arr:
        idx = abs(x) - 1
        if arr[idx] < 0:
            result.append(abs(x))
        else:
            arr[idx] = -arr[idx]
    # Restore array (optional, good practice)
    for i in range(len(arr)):
        arr[i] = abs(arr[i])
    return result

print(find_duplicates([4, 3, 2, 7, 8, 2, 3, 1]))  # [2, 3]
```

**Dry Run:** `arr = [4,3,2,7,8,2,3,1]`
- x=4 → idx=3, arr[3]=7>0 → mark negative → arr=[4,3,2,-7,8,2,3,1]
- x=3 → idx=2, arr[2]=2>0 → mark → arr=[4,3,-2,-7,8,2,3,1]
- x=2 → idx=1, arr[1]=3>0 → mark → arr=[4,-3,-2,-7,8,2,3,1]
- x=-7 → idx=abs(-7)-1=6, arr[6]=3>0 → mark → arr=[4,-3,-2,-7,8,2,-3,1]
- x=8 → idx=7, arr[7]=1>0 → mark → arr=[4,-3,-2,-7,8,2,-3,-1]
- x=2 → idx=1, arr[1]=-3<0 → **duplicate found: 2** → result=[2]
- x=-3 → idx=abs(-3)-1=2, arr[2]=-2<0 → **duplicate found: 3** → result=[2,3]
- x=1 → idx=0, arr[0]=4>0 → mark → arr=[-4,-3,-2,-7,8,2,-3,-1]

**Result: `[2, 3]`** ✅ Achieved with zero extra array/set!

---

## 10. Variant: Rotate Image / Matrix In-place (Transpose + Reverse)

**Problem:** Rotate an N×N matrix 90° clockwise in-place.

**Approach:** 1) Transpose the matrix (swap `matrix[i][j]` with `matrix[j][i]`), 2) Reverse each row.

```python
def rotate_matrix(matrix):
    n = len(matrix)
    # Transpose
    for i in range(n):
        for j in range(i + 1, n):
            matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]
    # Reverse each row
    for row in matrix:
        row.reverse()
    return matrix

m = [
    [1,2,3],
    [4,5,6],
    [7,8,9]
]
print(rotate_matrix(m))
# [[7,4,1],[8,5,2],[9,6,3]]
```

**Dry Run:**
Original:
```
1 2 3
4 5 6
7 8 9
```
After transpose:
```
1 4 7
2 5 8
3 6 9
```
After reversing each row:
```
7 4 1
8 5 2
9 6 3
```
✅ This is the matrix rotated 90° clockwise.

---

## 11. Variant: Merge Sorted Array In-place (from the back)

**Problem:** `nums1` has extra space at the end to hold `nums2`'s elements. Merge in-place without extra array.

```python
def merge(nums1, m, nums2, n):
    i, j, k = m - 1, n - 1, m + n - 1
    while j >= 0:
        if i >= 0 and nums1[i] > nums2[j]:
            nums1[k] = nums1[i]
            i -= 1
        else:
            nums1[k] = nums2[j]
            j -= 1
        k -= 1
    return nums1

nums1 = [1,2,3,0,0,0]
nums2 = [2,5,6]
print(merge(nums1, 3, nums2, 3))  # [1,2,2,3,5,6]
```

**Key trick:** Fill from the **back** of `nums1` (the largest empty slots) so you never overwrite values you still need to compare.

---

## 12. Common Problems Solved Using In-place Manipulation
1. Rotate Array — LeetCode 189
2. Move Zeroes — LeetCode 283
3. Remove Element — LeetCode 27
4. Remove Duplicates from Sorted Array — LeetCode 26, 80
5. Sort Colors (Dutch National Flag) — LeetCode 75
6. Rotate Image — LeetCode 48
7. Merge Sorted Array — LeetCode 88
8. Find All Duplicates in an Array — LeetCode 442
9. Set Matrix Zeroes — LeetCode 73
10. Next Permutation — LeetCode 31
11. Reverse String / Reverse Words in a String (in-place) — LeetCode 344, 151

---

## 13. Complexity Analysis

| Variant | Time | Space |
|---|---|---|
| Reverse array | O(n) | O(1) |
| Rotate array (reversal algorithm) | O(n) | O(1) |
| Move zeroes | O(n) | O(1) |
| Dutch National Flag (sort colors) | O(n) | O(1) |
| Find duplicates (sign flip marking) | O(n) | O(1) extra (besides output list) |
| Rotate matrix (transpose+reverse) | O(n²) | O(1) |
| Merge sorted array (from back) | O(m+n) | O(1) |

---

## 14. Key Takeaways
- In-place techniques are essential when the problem explicitly asks for **O(1) extra space**, which is common in interviews.
- Core toolkit: **swapping**, **two-pointer overwrite (read/write pointers)**, **sign-flip marking**, **value encoding**, and **reversal-based rotation**.
- Always be careful about **overwriting data you still need** — this is why "merge from the back" and "transpose before reverse" patterns exist (they avoid clobbering unread values).
- Sign-flip marking only works when you can **temporarily corrupt and later restore** values (e.g., all values are known to be positive) — always restore original values if the array must remain unmodified afterward for other checks.
- These techniques pair naturally with **Cyclic Traversal** (previous README) — both are about "no extra space" array algorithms, just using different mechanics (index permutation cycles vs. direct swapping/marking).
