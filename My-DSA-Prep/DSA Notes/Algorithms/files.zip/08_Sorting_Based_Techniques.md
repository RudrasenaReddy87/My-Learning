# Sorting-Based Techniques

## 1. What are Sorting-Based Techniques?

Many problems become dramatically easier once the input is **sorted**. Sorting-based techniques refer to both:
1. **The sorting algorithms themselves** (how to arrange data in order), and
2. **Problem-solving strategies that use sorting as the first step** to unlock two-pointers, greedy choices, binary search, or grouping patterns.

Sorting costs `O(n log n)` typically, but it often reduces an otherwise `O(n²)` or harder problem down to `O(n log n)`.

---

## 2. Types of Sorting Algorithms

| Algorithm | Time (Best) | Time (Average) | Time (Worst) | Space | Stable? |
|---|---|---|---|---|---|
| **Bubble Sort** | O(n) | O(n²) | O(n²) | O(1) | Yes |
| **Selection Sort** | O(n²) | O(n²) | O(n²) | O(1) | No |
| **Insertion Sort** | O(n) | O(n²) | O(n²) | O(1) | Yes |
| **Merge Sort** | O(n log n) | O(n log n) | O(n log n) | O(n) | Yes |
| **Quick Sort** | O(n log n) | O(n log n) | O(n²) | O(log n) | No |
| **Heap Sort** | O(n log n) | O(n log n) | O(n log n) | O(1) | No |
| **Counting Sort** | O(n+k) | O(n+k) | O(n+k) | O(k) | Yes |
| **Radix Sort** | O(d·(n+k)) | O(d·(n+k)) | O(d·(n+k)) | O(n+k) | Yes |
| **Bucket Sort** | O(n+k) | O(n+k) | O(n²) | O(n) | Yes |
| **Tim Sort** (Python/Java built-in) | O(n) | O(n log n) | O(n log n) | O(n) | Yes |

---

## 3. Sorting-Based *Problem-Solving Patterns* (Types)

| Pattern | Description | Use Case |
|---|---|---|
| **Sort + Two Pointers** | Sort array, then use converging pointers | Pair Sum, 3Sum, closest pair |
| **Sort + Greedy** | Sort by a key, then make locally optimal choices | Activity Selection, Job Scheduling, Meeting Rooms |
| **Sort + Binary Search** | Sort, then binary search for target/boundary | Searching in rotated/sorted arrays, k-th smallest |
| **Sort by Custom Comparator** | Sort using a custom rule (not natural order) | Largest number formed by array, merge intervals |
| **Sort + Sweep Line** | Sort events (start/end), then process sequentially | Interval overlap, meeting rooms, skyline problem |
| **Sort for Deduplication** | Sort makes duplicates adjacent for easy removal | Remove duplicates, group identical items |
| **Cycle Sort** | In-place sort in O(n) when values are in range [1,n] (used for "find missing/duplicate" problems) | Find missing/duplicate number (see Cyclic Traversal & In-place Manipulation README) |

---

## 4. Step-by-Step Approach — Merge Sort (Divide & Conquer)

1. If array has 0 or 1 elements, it's already sorted (base case).
2. Divide array into two halves.
3. Recursively sort the left half.
4. Recursively sort the right half.
5. **Merge** the two sorted halves into one sorted array.

## 5. Step-by-Step Approach — Quick Sort

1. Choose a **pivot** element (commonly last, first, or random element).
2. **Partition**: rearrange array so elements < pivot come before it, elements > pivot come after.
3. Recursively apply Quick Sort to left partition and right partition.

---

## 6. Dry Run — Merge Sort

Array: `arr = [38, 27, 43, 3, 9, 82, 10]`

**Step 1: Divide**
```
[38, 27, 43, 3, 9, 82, 10]
       /              \
[38, 27, 43, 3]      [9, 82, 10]
   /       \            /     \
[38,27]   [43,3]    [9,82]   [10]
 /  \       /  \      /  \
[38][27]  [43][3]  [9][82]
```

**Step 2: Merge back up**
```
[38] + [27] → [27, 38]
[43] + [3]  → [3, 43]
[27,38] + [3,43] → [3, 27, 38, 43]

[9] + [82] → [9, 82]
[9,82] + [10] → [9, 10, 82]

[3, 27, 38, 43] + [9, 10, 82] → [3, 9, 10, 27, 38, 43, 82]
```

**Final sorted array: `[3, 9, 10, 27, 38, 43, 82]`**

---

## 7. Dry Run — Quick Sort

Array: `arr = [10, 80, 30, 90, 40]`, pivot = last element

**Step 1: Partition around pivot=40**
```
i = -1 (boundary of "smaller" region)
j=0: arr[0]=10 < 40 → i=0, swap(arr[0],arr[0]) → [10,80,30,90,40]
j=1: arr[1]=80, not < 40 → skip
j=2: arr[2]=30 < 40 → i=1, swap(arr[1],arr[2]) → [10,30,80,90,40]
j=3: arr[3]=90, not < 40 → skip
Place pivot: swap(arr[i+1], arr[last]) → swap(arr[2], arr[4]) → [10,30,40,90,80]
Pivot 40 is now at index 2, correctly placed.
```

**Step 2: Recursively sort left `[10,30]` and right `[90,80]`**
- Left `[10,30]`: already sorted (or trivially sorted via recursion)
- Right `[90,80]`: pivot=80, partition → `[80,90]`

**Final sorted array: `[10, 30, 40, 80, 90]`**

---

## 8. Code Implementation

### Python (Merge Sort)
```python
def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i]); i += 1
        else:
            result.append(right[j]); j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result

print(merge_sort([38, 27, 43, 3, 9, 82, 10]))
# [3, 9, 10, 27, 38, 43, 82]
```

### Python (Quick Sort)
```python
def quick_sort(arr, low=0, high=None):
    if high is None:
        high = len(arr) - 1
    if low < high:
        pi = partition(arr, low, high)
        quick_sort(arr, low, pi - 1)
        quick_sort(arr, pi + 1, high)
    return arr

def partition(arr, low, high):
    pivot = arr[high]
    i = low - 1
    for j in range(low, high):
        if arr[j] < pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1

print(quick_sort([10, 80, 30, 90, 40]))
# [10, 30, 40, 80, 90]
```

### Java (Merge Sort)
```java
public class MergeSort {
    static void mergeSort(int[] arr, int l, int r) {
        if (l >= r) return;
        int mid = (l + r) / 2;
        mergeSort(arr, l, mid);
        mergeSort(arr, mid + 1, r);
        merge(arr, l, mid, r);
    }

    static void merge(int[] arr, int l, int mid, int r) {
        int[] left = java.util.Arrays.copyOfRange(arr, l, mid + 1);
        int[] right = java.util.Arrays.copyOfRange(arr, mid + 1, r + 1);
        int i = 0, j = 0, k = l;
        while (i < left.length && j < right.length) {
            arr[k++] = (left[i] <= right[j]) ? left[i++] : right[j++];
        }
        while (i < left.length) arr[k++] = left[i++];
        while (j < right.length) arr[k++] = right[j++];
    }

    public static void main(String[] args) {
        int[] arr = {38, 27, 43, 3, 9, 82, 10};
        mergeSort(arr, 0, arr.length - 1);
        System.out.println(java.util.Arrays.toString(arr));
    }
}
```

### C++ (Quick Sort)
```cpp
#include <bits/stdc++.h>
using namespace std;

int partition(vector<int>& arr, int low, int high) {
    int pivot = arr[high];
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (arr[j] < pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return i + 1;
}

void quickSort(vector<int>& arr, int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

int main() {
    vector<int> arr = {10, 80, 30, 90, 40};
    quickSort(arr, 0, arr.size() - 1);
    for (int x : arr) cout << x << " "; // 10 30 40 80 90
}
```

### JavaScript (Merge Sort)
```javascript
function mergeSort(arr) {
    if (arr.length <= 1) return arr;
    const mid = Math.floor(arr.length / 2);
    const left = mergeSort(arr.slice(0, mid));
    const right = mergeSort(arr.slice(mid));
    return merge(left, right);
}

function merge(left, right) {
    const result = [];
    let i = 0, j = 0;
    while (i < left.length && j < right.length) {
        result.push(left[i] <= right[j] ? left[i++] : right[j++]);
    }
    return result.concat(left.slice(i)).concat(right.slice(j));
}

console.log(mergeSort([38, 27, 43, 3, 9, 82, 10]));
```

---

## 9. Variant: Counting Sort (Non-Comparison Sort)

Used when values are integers in a **known small range** `[0, k]`. Runs in **O(n + k)**.

```python
def counting_sort(arr, max_val):
    count = [0] * (max_val + 1)
    for x in arr:
        count[x] += 1
    result = []
    for val, freq in enumerate(count):
        result.extend([val] * freq)
    return result

print(counting_sort([4, 2, 2, 8, 3, 3, 1], 8))
# [1, 2, 2, 3, 3, 4, 8]
```

**Dry run:** `arr = [4,2,2,8,3,3,1]`, max_val=8
```
count = [0,1,2,2,1,0,0,0,1]  # index=value, value=frequency
         0 1 2 3 4 5 6 7 8
```
Reconstruct: 1(x1), 2(x2), 3(x2), 4(x1), 8(x1) → `[1,2,2,3,3,4,8]` ✅

---

## 10. Variant: Sort by Custom Comparator (Largest Number)

**Problem:** Arrange numbers to form the largest possible number.

```python
from functools import cmp_to_key

def largest_number(nums):
    nums = list(map(str, nums))
    nums.sort(key=cmp_to_key(lambda a, b: (a+b > b+a) - (a+b < b+a)), reverse=True)
    result = ''.join(nums)
    return '0' if result[0] == '0' else result

print(largest_number([3, 30, 34, 5, 9]))  # "9534330"
```

---

## 11. Variant: Sort + Sweep Line (Merge Intervals)

```python
def merge_intervals(intervals):
    intervals.sort(key=lambda x: x[0])  # sort by start time
    merged = [intervals[0]]
    for curr in intervals[1:]:
        last = merged[-1]
        if curr[0] <= last[1]:  # overlapping
            last[1] = max(last[1], curr[1])
        else:
            merged.append(curr)
    return merged

print(merge_intervals([[1,3],[2,6],[8,10],[15,18]]))
# [[1,6],[8,10],[15,18]]
```

---

## 12. Variant: Sort + Greedy (Activity Selection)

```python
def max_activities(activities):
    # activities: list of (start, end)
    activities.sort(key=lambda x: x[1])  # sort by end time
    count = 1
    last_end = activities[0][1]
    for start, end in activities[1:]:
        if start >= last_end:
            count += 1
            last_end = end
    return count

acts = [(1,4), (3,5), (0,6), (5,7), (3,9), (5,9), (6,10), (8,11), (8,12), (2,14), (12,16)]
print(max_activities(acts))  # 4
```

---

## 13. Common Problems Solved Using Sorting-Based Techniques
1. Merge Intervals — LeetCode 56
2. Meeting Rooms I / II — LeetCode 252, 253
3. 3Sum / 4Sum — LeetCode 15, 18
4. Largest Number — LeetCode 179
5. Non-overlapping Intervals — LeetCode 435
6. Kth Largest Element (sort or quickselect) — LeetCode 215
7. Sort Colors (Dutch National Flag) — LeetCode 75
8. Top K Frequent Elements (bucket sort variant) — LeetCode 347
9. H-Index — LeetCode 274

---

## 14. Complexity Analysis Summary

| Technique | Time | Space | Notes |
|---|---|---|---|
| Comparison sorts (merge/quick/heap) | O(n log n) | O(n) or O(log n) | Lower bound for comparison-based sorting |
| Counting Sort | O(n + k) | O(k) | k = range of values |
| Radix Sort | O(d(n+k)) | O(n+k) | d = number of digits |
| Sort + Two Pointers (e.g. 3Sum) | O(n log n) + O(n²) | O(1) extra | Sorting dominates asymptotically for pair problems |
| Sort + Greedy (interval scheduling) | O(n log n) | O(1) extra | Sorting is the main cost |

---

## 15. Key Takeaways
- **Comparison-based sorts cannot beat O(n log n)** in the worst case (proven via decision tree lower bound) — but **non-comparison sorts** (counting, radix, bucket) can achieve **O(n)** when data has special structure (bounded range).
- Sorting is frequently the **first step**, not the final answer — it *enables* other techniques (two pointers, greedy, binary search) to work correctly.
- Always ask: "Does sorting lose information I need (like original indices)?" If so, sort `(value, original_index)` pairs instead of raw values.
- Choosing the right sort: use **Merge Sort** for guaranteed O(n log n) and stability; use **Quick Sort** for best average-case speed with in-place sorting; use **Counting/Radix Sort** when the value range is small and known.
